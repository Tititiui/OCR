plugins {
    id("org.jetbrains.kotlin.jvm")
    id("org.jetbrains.compose")
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation(project(":core"))
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.8.1")
    implementation("org.apache.pdfbox:pdfbox:2.0.31")
    implementation("net.sourceforge.tess4j:tess4j:5.11.0") { exclude(group = "org.apache.pdfbox") }
    runtimeOnly("org.slf4j:slf4j-nop:2.0.13")
}

compose.desktop {
    application {
        mainClass = "ship.desktop.MainKt"
        jvmArgs += listOf("-Xmx2g", "-Dskiko.renderApi=SOFTWARE", "-Dfile.encoding=UTF-8")
        nativeDistributions {
            packageName = "ShipTableOCR"
            packageVersion = "1.0.0"
            includeAllModules = true
            appResourcesRootDir.set(project.layout.projectDirectory.dir("resources"))
            windows { console = true }
        }
    }
}
