package ship.desktop

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ship.core.DocKind
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

fun pickPdf(): File? {
    val d = FileDialog(null as Frame?, "选择 PDF", FileDialog.LOAD)
    d.isVisible = true
    val f = d.file ?: return null
    return File(d.directory, f)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen() {
    var kind by remember { mutableStateOf(0) }
    var removeWm by remember { mutableStateOf(true) }
    var exportPdf by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<Result?>(null) }
    var errMsg by remember { mutableStateOf<String?>(null) }
    var savedFile by remember { mutableStateOf<File?>(null) }
    val scope = rememberCoroutineScope()

    fun start(pdf: File) {
        running = true; progress = 0f; status = "准备中…"; result = null; errMsg = null; savedFile = null
        val forced = when (kind) { 1 -> DocKind.SOUNDING; 2 -> DocKind.HYDRO; else -> null }
        val wm = removeWm
        val ep = exportPdf
        scope.launch {
            try {
                val pair = withContext(Dispatchers.Default) {
                    val rr = Pipeline.run(pdf, forced, wm, ep) { p ->
                        progress = p.done.toFloat() / maxOf(1, p.total)
                        status = p.msg
                    }
                    rr to Saver.save(pdf, rr)
                }
                result = pair.first
                savedFile = pair.second
                status = "完成"
            } catch (e: Throwable) {
                errMsg = e.message ?: e.toString()
            } finally {
                running = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("船舶表格识别", style = MaterialTheme.typography.headlineSmall)
        Text("测深表 / 静水力参数 → Excel(完全离线,不联网)", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("自动识别", "测深表", "静水力").forEachIndexed { i, t ->
                FilterChip(selected = kind == i, onClick = { kind = i }, label = { Text(t) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("去水印", Modifier.weight(1f))
            Switch(checked = removeWm, onCheckedChange = { removeWm = it })
        }
        if (removeWm) Row(verticalAlignment = Alignment.CenterVertically) {
            Text("同时导出去水印PDF(仅图片页)", Modifier.weight(1f))
            Switch(checked = exportPdf, onCheckedChange = { exportPdf = it })
        }
        Button(
            onClick = { val f = pickPdf(); if (f != null) start(f) },
            enabled = !running,
            modifier = Modifier.fillMaxWidth()
        ) { Text("选择 PDF 并开始识别") }
        if (running) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text(status)
        }
        errMsg?.let { Text("失败:$it", color = Color(0xFFB00020)) }
        result?.let { r ->
            val sm = r.summary
            savedFile?.let { f ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F4E8))) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("✓ 已自动保存 Excel:")
                        Text(f.absolutePath, style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = {
                            try { java.awt.Desktop.getDesktop().open(f.parentFile) } catch (e: Exception) { }
                        }) { Text("打开所在文件夹") }
                    }
                }
            }
            Card {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    sm.lines.forEach { Text(it) }
                    r.notes.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
            if (sm.review.isNotEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE0E0))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("★ 需要手动校对(趋势异常:${sm.review.size} 处)", color = Color(0xFFB00020), style = MaterialTheme.typography.titleSmall)
                        sm.review.take(40).forEach { Text("${it.where} · 第${it.page}页 · ${it.pos}\n   ${it.msg}", style = MaterialTheme.typography.bodySmall) }
                        if (sm.review.size > 40) Text("…其余 ${sm.review.size - 40} 处见 Excel「待校对清单」")
                    }
                }
            } else Text("✓ 未发现趋势异常", color = Color(0xFF1B7F3B))
            val other = sm.issues.filter { it.msg.contains("无法") || it.msg.contains("未识别") || it.msg.contains("缺失") || it.msg.contains("校正") }
            if (other.isNotEmpty()) Card {
                Column(Modifier.padding(12.dp)) {
                    Text("识别问题 / 自动校正(${other.size})", style = MaterialTheme.typography.titleSmall)
                    other.take(15).forEach { Text("${it.where} · 第${it.page}页 · ${it.pos}: ${it.msg}", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

fun reportCrash(t: Throwable) {
    val sw = java.io.StringWriter()
    t.printStackTrace(java.io.PrintWriter(sw))
    try { File(System.getProperty("user.home"), "ShipTableOCR-error.log").writeText(sw.toString()) } catch (e: Exception) { }
    try {
        javax.swing.JOptionPane.showMessageDialog(
            null,
            "程序出错:\n" + (t.message ?: t.toString()) + "\n\n详细信息已保存到:用户文件夹\\ShipTableOCR-error.log",
            "船舶表格识别", javax.swing.JOptionPane.ERROR_MESSAGE
        )
    } catch (e: Throwable) { }
}

fun main() {
    Thread.setDefaultUncaughtExceptionHandler { _, e -> reportCrash(e) }
    try {
        application {
            Window(
                onCloseRequest = ::exitApplication,
                title = "船舶表格识别",
                state = rememberWindowState(width = 900.dp, height = 800.dp)
            ) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } }
            }
        }
    } catch (e: Throwable) {
        reportCrash(e)
    }
}
