package ship.desktop

import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.graphics.image.JPEGFactory
import org.apache.pdfbox.rendering.ImageType
import org.apache.pdfbox.rendering.PDFRenderer
import ship.core.*
import java.io.File

class Progress(val done: Int, val total: Int, val msg: String)
class Result(val xlsx: ByteArray, val summary: Summary, val cleanPdf: File?, val notes: List<String>, val baseName: String)

/** PDF → (text layer | watermark removal + OCR) → lines → parsers → validation → .xlsx. Everything is local. */
object Pipeline {
    fun run(src: File, forced: DocKind?, removeWatermark: Boolean, exportCleanPdf: Boolean, onProgress: (Progress) -> Unit): Result {
        val displayName = src.name
        val notes = ArrayList<String>()
        val issues = ArrayList<Issue>()
        val pages = ArrayList<PageContent>()
        var ocr: OcrEngine? = null
        val outDoc: PDDocument? = if (removeWatermark && exportCleanPdf) PDDocument() else null
        var wmText = 0; var wmRaster = 0; var rasterPages = 0; var textPages = 0

        PDDocument.load(src).use { doc ->
            val renderer = PDFRenderer(doc)
            val n = doc.numberOfPages
            for (i in 0 until n) {
                onProgress(Progress(i, n, "第 ${i + 1}/$n 页"))
                val tx = PdfText.extract(doc, i, removeWatermark)
                if (tx.rotatedChars > 0) wmText++
                if (PdfText.usable(tx)) {
                    textPages++
                    pages.add(PageContent(i + 1, tx.lines.map { TextLine.fromString(it) }, false))
                    continue
                }
                // image page (scan / photo): render -> optional watermark removal -> OCR
                val box = doc.getPage(i).mediaBox
                val maxPts = maxOf(box.width, box.height)
                val dpi = minOf(324f, 3800f * 72f / maxPts)
                val bi = renderer.renderImageWithDPI(i, dpi, ImageType.RGB)
                val w = bi.width
                val h = bi.height
                val px = bi.getRGB(0, 0, w, h, null, 0, w)
                val rep = Watermark.detect(px, w, h)
                if (rep.likely) wmRaster++
                if (removeWatermark && rep.likely) {
                    Watermark.remove(px, w, h)
                    bi.setRGB(0, 0, w, h, px, 0, w)
                }
                if (outDoc != null) {
                    val page = PDPage(PDRectangle(w * 72f / dpi, h * 72f / dpi))
                    outDoc.addPage(page)
                    val img = JPEGFactory.createFromImage(outDoc, bi, 0.9f)
                    PDPageContentStream(outDoc, page).use { cs -> cs.drawImage(img, 0f, 0f, w * 72f / dpi, h * 72f / dpi) }
                }
                val engine = ocr ?: OcrEngine().also { ocr = it }
                onProgress(Progress(i, n, "第 ${i + 1}/$n 页 · 文字识别中(较慢,请稍候)"))
                val words = engine.words(bi)
                bi.flush()
                rasterPages++
                pages.add(PageContent(i + 1, LineBuilder.build(words), true))
            }
        }

        var cleanFile: File? = null
        if (outDoc != null) {
            if (rasterPages > 0) {
                cleanFile = File.createTempFile("cleaned", ".pdf")
                outDoc.save(cleanFile)
            }
            outDoc.close()
        }

        notes.add("页面来源: 文字层 $textPages 页(数字无误差) / 图片OCR $rasterPages 页")
        if (wmText + wmRaster > 0) {
            notes.add(
                if (removeWatermark) "已检测并去除水印:文字层斜向文字 $wmText 页、图片水印 $wmRaster 页(原文件未被修改)"
                else "检测到水印(文字层 $wmText 页 / 图片 $wmRaster 页),但「去水印」未开启,识别可能受影响"
            )
        }
        if (wmText > 0 && removeWatermark) notes.add("文字层PDF的水印仅在识别时被忽略,不会改写原PDF;去水印后的PDF只对图片页生成。")

        val kind = forced
            ?: pages.mapNotNull { Parsers.classify(it.lines) }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            ?: throw IllegalStateException("无法判断是测深表还是静水力表,请在界面中手动选择类型")
        val tables = if (kind == DocKind.SOUNDING) Parsers.sounding(pages, issues) else listOf(Parsers.hydro(pages, issues))
        if (tables.isEmpty() || tables.all { it.rows.isEmpty() }) throw IllegalStateException("没有识别到任何表格数据行")
        onProgress(Progress(pages.size, pages.size, "生成 Excel…"))
        val (bytes, summary) = Export.build(kind, tables, displayName, issues, notes.joinToString("  |  "))
        return Result(bytes, summary, cleanFile, notes, displayName.substringBeforeLast('.'))
    }
}

/** Saves the results next to the source PDF (falls back to Documents / home folder). */
object Saver {
    fun save(pdf: File, r: Result): File {
        val home = System.getProperty("user.home")
        val dirs = listOfNotNull(pdf.absoluteFile.parentFile, File(home, "Documents"), File(home))
        for (d in dirs) {
            try {
                if (!d.isDirectory) continue
                val x = File(d, r.baseName + "_识别结果.xlsx")
                x.writeBytes(r.xlsx)
                r.cleanPdf?.copyTo(File(d, r.baseName + "_去水印.pdf"), overwrite = true)
                return x
            } catch (e: Exception) {
            }
        }
        throw IllegalStateException("无法保存结果文件,请检查文件夹是否可写")
    }
}
