package ship.desktop

import net.sourceforge.tess4j.Tesseract
import ship.core.OcrWord
import java.awt.image.BufferedImage
import java.io.File

/** Locates the bundled OCR language data (eng.traineddata). Tesseract cannot read non-ASCII paths, so copy if needed. */
object Tessdata {
    fun dir(): File {
        val res = System.getProperty("compose.application.resources.dir")
        val candidates = listOfNotNull(
            res?.let { File(it, "tessdata") },
            File("resources/common/tessdata"),
            File("desktop/resources/common/tessdata")
        )
        val src = candidates.firstOrNull { File(it, "eng.traineddata").isFile }
            ?: throw IllegalStateException("找不到 OCR 语言数据 eng.traineddata")
        if (src.absolutePath.all { it.code < 128 }) return src
        val bases = listOfNotNull(System.getenv("PUBLIC"), "C:\\ShipTableOCR")
        for (b in bases) {
            val target = File(b, "ShipTableOCR_tessdata")
            if (!target.absolutePath.all { it.code < 128 }) continue
            try {
                target.mkdirs()
                val f = File(target, "eng.traineddata")
                val s = File(src, "eng.traineddata")
                if (!f.isFile || f.length() != s.length()) s.copyTo(f, overwrite = true)
                return target
            } catch (e: Exception) {
            }
        }
        return src
    }
}

/** Offline Tesseract OCR (language data ships inside the app). Returns word boxes in page pixels. */
class OcrEngine {
    private val tess = Tesseract().apply {
        setDatapath(Tessdata.dir().absolutePath)
        setLanguage("eng")
        setPageSegMode(6)
        setOcrEngineMode(1)
        setTessVariable("user_defined_dpi", "300")
    }

    fun words(img: BufferedImage): List<OcrWord> {
        val out = ArrayList<OcrWord>()
        // 3 = word level (RIL_WORD)
        for (w in tess.getWords(img, 3)) {
            val t = w.text?.trim() ?: continue
            if (t.isEmpty()) continue
            val r = w.boundingBox
            out.add(OcrWord(t, r.x.toFloat(), r.y.toFloat(), (r.x + r.width).toFloat(), (r.y + r.height).toFloat()))
        }
        return out
    }
}
