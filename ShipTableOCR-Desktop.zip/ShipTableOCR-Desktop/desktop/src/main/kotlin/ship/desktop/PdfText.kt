package ship.desktop

import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.text.PDFTextStripper
import org.apache.pdfbox.text.TextPosition

/** Text-layer extraction (exact digits). Diagonal text (= typical watermark) is counted and optionally dropped. */
object PdfText {
    class PageText(val lines: List<String>, val rotatedChars: Int)

    private class Stripper(private val dropRotated: Boolean) : PDFTextStripper() {
        var rotated = 0
        init { sortByPosition = true }
        override fun processTextPosition(text: TextPosition) {
            val m = text.textMatrix
            var a = Math.toDegrees(Math.atan2(m.shearY.toDouble(), m.scaleX.toDouble()))
            a = ((a % 360) + 360) % 360
            val diag = (a > 3 && a < 87) || (a > 93 && a < 177) || (a > 183 && a < 267) || (a > 273 && a < 357)
            if (diag) { rotated++; if (dropRotated) return }
            super.processTextPosition(text)
        }
    }

    fun extract(doc: PDDocument, pageIndex: Int, dropRotated: Boolean): PageText = try {
        val s = Stripper(dropRotated)
        s.startPage = pageIndex + 1
        s.endPage = pageIndex + 1
        PageText(s.getText(doc).split('\n').map { it.trimEnd() }.filter { it.isNotBlank() }, s.rotated)
    } catch (e: Throwable) {
        PageText(emptyList(), 0)
    }

    /** A page "has a usable text layer" when it contains plenty of decimal numbers. */
    fun usable(p: PageText): Boolean = p.lines.sumOf { Regex("\\d+\\.\\d+").findAll(it).count() } >= 30
}
