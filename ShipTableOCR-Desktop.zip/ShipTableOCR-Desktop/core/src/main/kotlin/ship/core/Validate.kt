package ship.core

import kotlin.math.abs

/** A table after consistency checks. Cells are addressed as (rowIndex, colIndex). */
class Checked(val table: Table, val cols: List<Col>) {
    val vals: List<Array<Double?>?> = table.rows.map { it.v?.copyOf() }
    val anoms = LinkedHashMap<Pair<Int, Int>, String>()      // RED: trend anomaly / spike → please verify by hand
    val flags = LinkedHashMap<Pair<Int, Int>, String>()      // yellow: other suspicious
    val fixed = LinkedHashMap<Pair<Int, Int>, String>()      // orange: auto-corrected
    val missingCols = HashSet<Int>()                          // columns absent on (almost) every row
    fun flag(r: Int, c: Int, msg: String) { if ((r to c) !in anoms) flags.putIfAbsent(r to c, msg) }
}

object Validate {
    private fun median(xs: List<Double>): Double = if (xs.isEmpty()) 0.0 else xs.sorted()[xs.size / 2]

    private fun markMissing(c: Checked) {
        for (ci in c.cols.indices) {
            val miss = c.vals.count { it != null && it[ci] == null }
            val ok = c.vals.count { it != null }
            if (ok > 0 && miss >= ok * 0.9) c.missingCols.add(ci)
        }
        for ((ri, v) in c.vals.withIndex()) {
            if (v == null) continue
            for (ci in c.cols.indices) if (v[ci] == null && ci !in c.missingCols) c.flag(ri, ci, "该单元格未识别")
        }
    }

    /** Trend analysis per column; [skip] = column keys that legitimately wiggle (HC*, IMOM) or are axes. */
    private fun trends(c: Checked, skip: (Col) -> Boolean) {
        for ((ci, col) in c.cols.withIndex()) {
            if (skip(col)) continue
            val idx = c.vals.indices.filter { c.vals[it]?.get(ci) != null }
            if (idx.size < 12) continue
            val xs = idx.map { c.vals[it]!![ci]!! }
            for ((k, why) in Trend.anomalies(xs, col.dec)) c.anoms[idx[k] to ci] = why
        }
    }

    fun sounding(t: Table): Checked {
        val c = Checked(t, Schemas.sounding)
        val vals = c.vals
        markMissing(c)
        val gl = vals.indices.filter { vals[it]?.get(0) != null && vals[it]?.get(1) != null }
        if (gl.size >= 3) {
            val sumConst = gl.groupingBy { (vals[it]!![0]!! + vals[it]!![1]!!).toInt() }.eachCount().maxByOrNull { it.value }!!.key
            val diffs = gl.zipWithNext().map { (a, b) -> (vals[b]!![0]!! - vals[a]!![0]!!).toInt() }.filter { it > 0 }
            val step = diffs.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: 5
            val last = gl.last()
            var prev: Int? = null
            for (i in gl) {
                val v = vals[i]!!
                var g = v[0]!!.toInt(); val u = v[1]!!.toInt()
                // Source rounding makes GAUGE+ULL differ by ±1 on a few rows; more than that = misread digit.
                if (abs(g + u - sumConst) > 1) {
                    val expG = prev?.plus(step)
                    if (expG != null && g != expG && abs(u - (sumConst - expG)) <= 1) {
                        c.fixed[i to 0] = "GAUGE $g→$expG(按序列与ULL校正)"; v[0] = expG.toDouble(); g = expG
                    } else {
                        c.fixed[i to 1] = "ULL $u→${sumConst - g}(按 GAUGE+ULL=$sumConst 校正)"; v[1] = (sumConst - g).toDouble()
                    }
                }
                if (prev != null && i != last && g - prev != step)
                    c.flag(i, 0, if (g - prev > step) "测深间隔异常,疑似漏行/误识别" else "测深值未递增")
                prev = g
            }
            val full = gl.filter { vals[it]!![2] != null }
            if (full.isNotEmpty()) {
                val cap = full.maxOf { vals[it]!![2]!! }
                for (i in full) {
                    val f = vals[i]!![19]
                    if (f != null && cap > 0 && abs(100 * vals[i]!![2]!! / cap - f) > 3) c.flag(i, 19, "FILL 与容积不符")
                }
            }
        }
        trends(c) { it.key == "gauge" || it.key == "ull" || it.key.startsWith("HC") || it.key == "imom" }
        return c
    }

    fun hydro(t: Table): Checked {
        val cols = t.cols ?: Schemas.hydro
        val c = Checked(t, cols)
        val vals = c.vals
        markMissing(c)
        val iTK = cols.indexOfFirst { it.key == "TK" }
        val gl = vals.indices.filter { vals[it]?.get(0) != null }
        if (iTK > 0) for (i in gl) {
            val v = vals[i]!!
            if (v[iTK] != null && abs(v[iTK]!! - v[0]!! - 0.017) > 0.0015) c.flag(i, iTK, "TK ≠ T+0.017")
        }
        trends(c) { it.key == "T" || it.key == "TK" }
        // continuity (yellow): jump in magnitude of the step although the direction is unchanged
        for (ci in 2 until cols.size) {
            val dec = cols[ci].dec
            val idx = gl.filter { vals[it]!![ci] != null }
            if (idx.size < 5) continue
            val resid = (1 until idx.size - 1).map { k ->
                abs(vals[idx[k]]!![ci]!! - (vals[idx[k - 1]]!![ci]!! + vals[idx[k + 1]]!![ci]!!) / 2)
            }
            for (k in 1 until idx.size - 1) {
                val a = vals[idx[k - 1]]!!; val b = vals[idx[k]]!!; val d = vals[idx[k + 1]]!!
                val span = d[0]!! - a[0]!!
                if (span == 0.0) continue
                val w = (b[0]!! - a[0]!!) / span          // spacing-aware: tables contain irregular extra rows
                val res = abs(b[ci]!! - (a[ci]!! + (d[ci]!! - a[ci]!!) * w))
                val lo = maxOf(0, k - 1 - 10); val hi = minOf(resid.size, k - 1 + 10)
                val sc = if (hi > lo) median(resid.subList(lo, hi)) else 0.0
                if (res > maxOf(6 * sc, 4 * Math.pow(10.0, -dec.toDouble()), 0.0006 * abs(b[ci]!!)))
                    c.flag(idx[k], ci, "步长突变(源表数据疑似异常或识别错误)")
            }
        }
        return c
    }
}
