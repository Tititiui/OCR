# 船舶表格识别 (ShipTableOCR)

测深表 (Sounding Table) / 静水力参数 (Hydrostatics) 的 PDF → Excel。**完全离线**(Manifest 里没有 INTERNET 权限)。

## 结构
- `core/` 纯 Kotlin/JVM,无 Android 依赖 → **以后做 Windows 版直接复用**(Compose Desktop + PDFBox JVM + Tesseract/Windows OCR 替换 `app/OcrEngine.kt`)
  - `Layout.kt` OCR 词框 → 行(自动估计页面倾斜)
  - `Numbers.kt` 按"每列固定小数位"拆分粘连数字(如 `170.80-10.00`)、补小数点、右侧被裁切时保留缺失列
  - `Parsers.kt` 测深表按舱分表;静水力按表头识别列,多组表头按 T 合并成一张表
  - `Trend.kt` 趋势分析(单调/先降后升/先升后降/平台都算正常;连续趋势中突然反向数步又恢复、孤立尖峰 → 红色)
  - `Validate.kt` 其余校验(GAUGE+ULL 恒等 ±1、测深步长、FILL 与容积、TK=T+0.017 …)
  - `Watermark.kt` 离线去水印(Otsu 找墨迹阈值,只清除不贴近墨迹的灰/彩色像素)
  - `Xlsx.kt` / `Export.kt` 无依赖 xlsx 写入与排版
- `app/` Android:`PdfText.kt`(PDFBox 文字层,可丢弃斜向水印文字) · `OcrEngine.kt`(ML Kit 内置模型,分条带识别) · `Pipeline.kt` · `MainActivity.kt`
- `tools/` Python 参考实现(文本层 PDF):`python extract.py sounding|hydro in.pdf out.xlsx`

## 构建
Android Studio (Koala+),JDK 17,打开本目录 → Run `app`。首次需联网只为 Gradle 下载依赖;安装后的 App 不联网。
`./gradlew :core:test` 运行核心单元测试。

## Excel 颜色
红=趋势异常/无法识别(见「待校对清单」) · 黄=其他可疑 · 橙=已自动校正。最后一个 sheet「生成效果说明」列出每个舱/页的问题。
