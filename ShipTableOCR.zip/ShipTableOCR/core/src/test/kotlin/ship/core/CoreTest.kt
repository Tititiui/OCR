package ship.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class CoreTest {
    @Test fun gluedTokensAreSplitByDecimals() {
        // real line from the sounding manual: "170.80-10.00" are two columns glued together
        val line = TextLine.fromString("  375 1728   798.54   796.78   794.98   793.15   791.29   789.40   787.48   785.52   783.53   800.27   801.97   -29.70   -19.31    -9.41    25.00    17.23     8.89   51.2   170.80-10.00 1.25      22.6")
        val r = Numbers.parseRow(line, Schemas.sounding, 2, null, 1)
        assertEquals(24, r.v!!.size)
        assertEquals(170.80, r.v!![20]); assertEquals(-10.00, r.v!![21]); assertEquals(22.6, r.v!![23])
    }
    @Test fun truncatedRightEdgeLeavesMissingTail() {
        val line = TextLine.fromString("2.000 2.017 11130.3 11525.5 120.807 0.7650 121.504 1.021 42.172 1541.354 11244.4 218.38 5923.0 6361.0 60.7 787.3 0.8129 0.7839")
        val r = Numbers.parseRow(line, Schemas.hydro, 0, null, 1)
        assertEquals(null, r.v!![18]); assertEquals(0.7839, r.v!![17])
    }
    @Test fun trendFlagsReversalButNotPlateau() {
        val falling = (0 until 30).map { 199.0 - 0.05 * it }
        val plateau = falling + List(30) { falling.last() }
        assertTrue(Trend.anomalies(plateau, 2).isEmpty())
        val bad = falling.toMutableList(); for (i in 12..14) bad[i] = bad[11] + 0.05 * (i - 11)
        assertTrue(Trend.anomalies(bad, 2).isNotEmpty())
    }
    @Test fun isolatedSpikeInFlatSeries() {
        val xs = MutableList(40) { 218.77 }; xs[20] = 78.10
        assertTrue(20 in Trend.anomalies(xs, 2))
    }
}
