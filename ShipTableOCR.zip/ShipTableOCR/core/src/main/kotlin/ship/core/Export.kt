package ship.core

import java.io.ByteArrayOutputStream

class Summary(
    val kind: DocKind, val tables: Int, val rows: Int, val unreadableRows: Int,
    val autoFixed: Int, val suspicious: Int, val anomalies: Int, val review: List<Issue>,
    val issues: List<Issue>, val lines: List<String>
)

object Export {
    private fun safeSheet(name: String, used: MutableSet<String>): String {
        var n = name.replace(Regex("[:\\\\/?*\\[\\]]"), "-").trim().take(31).ifEmpty { "Sheet" }
        val base = n; var k = 2
        while (n.lowercase() in used) { n = base.take(28) + "_$k"; k++ }
        used.add(n.lowercase()); return n
    }

    fun build(kind: DocKind, tables: List<Table>, source: String, extra: List<Issue>, note: String): Pair<ByteArray, Summary> {
        val wb = XWorkbook()
        val used = HashSet<String>()
        val issues = ArrayList<Issue>(extra)
        val rowsOut = ArrayList<List<Any>>()
        var tRows = 0; var tBad = 0; var tFix = 0; var tFlag = 0; var tAnom = 0
        val review = ArrayList<Issue>()
        val reviewVals = ArrayList<List<Any>>()
        for (t in tables) {
            val c = if (kind == DocKind.SOUNDING) Validate.sounding(t) else Validate.hydro(t)
            val sh = wb.addSheet(safeSheet(t.name, used))
            val m = t.meta
            val metaLines = if (kind == DocKind.SOUNDING) listOf(
                "Compartment ident: ${m.ident ?: ""}   |   ${m.contents ?: ""}",
                m.extreme.joinToString("   "), m.device.joinToString("   "),
                "来源页(PDF页码): ${t.pages.firstOrNull() ?: "-"}–${t.pages.lastOrNull() ?: "-"}   行数: ${t.rows.size}   (Volume in m³)"
            ) else listOf(
                "${t.meta.contents ?: ""}   |   来源页(PDF页码): ${t.pages.firstOrNull() ?: "-"}–${t.pages.lastOrNull() ?: "-"}   行数: ${t.rows.size}"
            )
            writeTable(wb, sh, if (kind == DocKind.SOUNDING) t.name else "静水力参数表 Hydrostatic Table", metaLines, c)
            val bad = c.vals.count { it == null }
            tRows += t.rows.size; tBad += bad; tFix += c.fixed.size; tFlag += c.flags.size; tAnom += c.anoms.size
            for ((k, msg) in c.anoms) {
                val v = c.vals[k.first]
                val lab = if (kind == DocKind.HYDRO) "T=${v?.get(0) ?: "?"}" else "GAUGE=${v?.get(0)?.toInt() ?: "?"}"
                val it = Issue(t.name, t.rows[k.first].page, "$lab  列${c.cols[k.second].label}", msg)
                review.add(it); reviewVals.add(listOf(it.where, it.page, it.pos, v?.get(k.second) ?: "", it.msg))
            }
            for ((ci) in c.missingCols.map { it to 0 })
                issues.add(Issue(t.name, t.pages.firstOrNull() ?: 0, "列 ${c.cols[ci].label}", "该列在源图中缺失(疑似被裁切),已留空"))
            for ((k, msg) in c.fixed) issues.add(Issue(t.name, t.rows[k.first].page, "行${k.first + 1} 列${c.cols[k.second].label}", "已自动校正: $msg"))
            var listed = 0
            for ((k, msg) in c.flags) {
                if (listed >= 300) break
                val lab = if (kind == DocKind.HYDRO) "T=${c.vals[k.first]?.get(0) ?: "?"} " else "行${k.first + 1} "
                issues.add(Issue(t.name, t.rows[k.first].page, lab + "列${c.cols[k.second].label}", msg)); listed++
            }
            if (c.flags.size > listed) issues.add(Issue(t.name, 0, "…", "另有 ${c.flags.size - listed} 条可疑单元格未逐条列出(表内已标黄)"))
            c.vals.forEachIndexed { i, v -> if (v == null) issues.add(Issue(t.name, t.rows[i].page, "行${i + 1}", "整行无法解析")) }
            rowsOut.add(listOf(t.name, "${t.pages.firstOrNull() ?: "-"}–${t.pages.lastOrNull() ?: "-"}", t.rows.size, bad, c.fixed.size, c.flags.size))
        }
        writeReview(wb, reviewVals)
        writeReport(wb, source, note, kind, rowsOut, issues)
        val bos = ByteArrayOutputStream(); wb.write(bos)
        val lines = listOf(
            "类型: ${if (kind == DocKind.SOUNDING) "测深表" else "静水力参数"}",
            "舱/表数量: ${tables.size}    数据行: $tRows",
            "整行无法解析: $tBad    自动校正: $tFix    可疑单元格: $tFlag",
            "★ 趋势异常(红色,需手动校对): $tAnom"
        )
        return bos.toByteArray() to Summary(kind, tables.size, tRows, tBad, tFix, tFlag, tAnom, review, issues, lines)
    }

    private fun writeTable(wb: XWorkbook, sh: XSheet, title: String, meta: List<String>, c: Checked) {
        val cols = c.cols
        sh.text(1, 1, title, wb.style(font = XWorkbook.F_TITLE))
        sh.heights[1] = 26.0
        var r = 2
        for (m in meta) { if (m.isBlank()) continue; sh.text(r, 1, m, wb.style(font = XWorkbook.F_META)); r++ }
        r++
        val hasGroups = cols.any { it.group.isNotEmpty() }
        val grpRow = r
        if (hasGroups) {
            val sg = wb.style(font = XWorkbook.F_WHITE_B, fill = XWorkbook.FILL_GRP, align = "center")
            var i = 0
            while (i < cols.size) {
                var e = i
                while (e + 1 < cols.size && cols[e + 1].group == cols[i].group) e++
                for (k in i..e) sh.blank(grpRow, k + 1, sg)
                sh.text(grpRow, i + 1, cols[i].group, sg)
                if (e > i) sh.merges.add("${XWorkbook.colName(i + 1)}$grpRow:${XWorkbook.colName(e + 1)}$grpRow")
                i = e + 1
            }
            r++
        }
        val hdrRow = r; val unitRow = r + 1; val data0 = r + 2
        val sh1 = wb.style(font = XWorkbook.F_WHITE_B, fill = XWorkbook.FILL_HDR, border = true, align = "center")
        val su = wb.style(font = XWorkbook.F_UNIT, fill = XWorkbook.FILL_UNIT, border = true, align = "center")
        cols.forEachIndexed { i, col ->
            sh.text(hdrRow, i + 1, col.label, sh1)
            sh.text(unitRow, i + 1, col.unit, su)
            sh.widths[i + 1] = maxOf(9.0, col.label.length + 3.0, if (col.dec >= 2) 11.0 else 9.0)
        }
        sh.heights[hdrRow] = 20.0
        for ((ri, v) in c.vals.withIndex()) {
            for (ci in cols.indices) {
                val key = ri to ci
                val fill = when {
                    v == null || (v[ci] == null) -> XWorkbook.FILL_RED
                    key in c.anoms -> XWorkbook.FILL_RED
                    key in c.flags -> XWorkbook.FILL_YEL
                    key in c.fixed -> XWorkbook.FILL_ORG
                    ri % 2 == 1 -> XWorkbook.FILL_ZEB
                    else -> 0
                }
                val st = wb.style(font = if (key in c.anoms) XWorkbook.F_BOLD else 0, fill = fill, dec = cols[ci].dec, border = true, align = "right")
                val x = v?.get(ci)
                if (x != null) sh.num(data0 + ri, ci + 1, x, st) else sh.blank(data0 + ri, ci + 1, st)
            }
        }
        sh.freezeRow = data0 - 1
        sh.freezeCol = if (cols.size > 19) 2 else 1
        if (c.vals.isNotEmpty()) sh.filter = "A$hdrRow:${XWorkbook.colName(cols.size)}${data0 + c.vals.size - 1}"
    }

    private fun writeReview(wb: XWorkbook, rows: List<List<Any>>) {
        val sh = wb.addSheet("待校对清单")
        sh.text(1, 1, "待校对清单(趋势异常,请对照原件手动校对)", wb.style(font = XWorkbook.F_TITLE)); sh.heights[1] = 26.0
        sh.text(2, 1, "判定规则:数据应呈单调上升/下降,或先降后升/先升后降;不变(平台)属正常。连续趋势中突然反向数步又恢复、或孤立尖峰 → 标红。水箱接近满舱处的小幅抖动可能是源表本身的特性。", wb.style(font = XWorkbook.F_META))
        val hs = wb.style(font = XWorkbook.F_WHITE_B, fill = XWorkbook.FILL_HDR, border = true)
        listOf("舱 / 表", "页码", "位置", "数值", "原因").forEachIndexed { i, h -> sh.text(4, i + 1, h, hs) }
        val red = wb.style(fill = XWorkbook.FILL_RED, border = true)
        var r = 4
        if (rows.isEmpty()) sh.text(5, 1, "未发现趋势异常", wb.style())
        for (row in rows) {
            r++
            sh.text(r, 1, row[0].toString(), wb.style(border = true)); sh.num(r, 2, (row[1] as Int).toDouble(), wb.style(border = true))
            sh.text(r, 3, row[2].toString(), wb.style(border = true))
            val v = row[3]; if (v is Double) sh.num(r, 4, v, red) else sh.blank(r, 4, red)
            sh.text(r, 5, row[4].toString(), wb.style(border = true))
        }
        sh.widths[1] = 30.0; sh.widths[2] = 8.0; sh.widths[3] = 34.0; sh.widths[4] = 14.0; sh.widths[5] = 60.0
        if (rows.isNotEmpty()) sh.filter = "A4:E$r"
        sh.freezeRow = 4
    }

    private fun writeReport(wb: XWorkbook, source: String, note: String, kind: DocKind, summary: List<List<Any>>, issues: List<Issue>) {
        val sh = wb.addSheet("生成效果说明")
        sh.text(1, 1, "生成效果说明", wb.style(font = XWorkbook.F_TITLE)); sh.heights[1] = 26.0
        sh.text(2, 1, "来源文件: $source    类型: ${if (kind == DocKind.SOUNDING) "测深表 Sounding Table" else "静水力参数 Hydrostatics"}", wb.style(font = XWorkbook.F_META))
        if (note.isNotBlank()) sh.text(3, 1, note, wb.style(font = XWorkbook.F_META))
        sh.text(4, 1, "颜色: 红=趋势异常或无法识别(必须手动校对,见「待校对清单」)   黄=其他可疑(请对照原件)   橙=已按校验规则自动校正", wb.style(font = XWorkbook.F_META))
        val hs = wb.style(font = XWorkbook.F_WHITE_B, fill = XWorkbook.FILL_HDR, border = true)
        var r = 6
        listOf("舱 / 表", "来源页", "数据行", "无法解析行", "自动校正", "可疑单元格").forEachIndexed { i, h -> sh.text(r, i + 1, h, hs) }
        val sn = wb.style(border = true); val sy = wb.style(fill = XWorkbook.FILL_YEL, border = true)
        for (row in summary) {
            r++
            row.forEachIndexed { i, v ->
                val st = if (i >= 3 && (v as? Int ?: 0) > 0) sy else sn
                if (v is Int) sh.num(r, i + 1, v.toDouble(), st) else sh.text(r, i + 1, v.toString(), st)
            }
        }
        r += 2
        sh.text(r, 1, "问题明细(识别失败 / 校正 / 可疑)", wb.style(font = XWorkbook.F_BOLD))
        r++
        listOf("舱 / 表", "页码", "位置", "说明").forEachIndexed { i, h -> sh.text(r, i + 1, h, hs) }
        if (issues.isEmpty()) sh.text(r + 1, 1, "未发现问题", wb.style())
        for (it in issues) {
            r++
            sh.text(r, 1, it.where); if (it.page > 0) sh.num(r, 2, it.page.toDouble()); sh.text(r, 3, it.pos); sh.text(r, 4, it.msg)
        }
        sh.widths[1] = 30.0; sh.widths[2] = 12.0; sh.widths[3] = 28.0; sh.widths[4] = 70.0; sh.widths[5] = 12.0; sh.widths[6] = 14.0
    }
}
