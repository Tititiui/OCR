package ship.core

import java.io.OutputStream
import java.util.TreeMap
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Minimal dependency-free .xlsx writer (works on Android and desktop JVM). */
data class XStyle(val font: Int = 0, val fill: Int = 0, val dec: Int = -1, val border: Boolean = false, val align: String = "")

class XSheet(val name: String) {
    class Cell(val s: String?, val n: Double?, val style: Int)
    val rows = TreeMap<Int, TreeMap<Int, Cell>>()
    val merges = ArrayList<String>()
    val widths = HashMap<Int, Double>()
    val heights = HashMap<Int, Double>()
    var freezeRow = 0
    var freezeCol = 0
    var filter: String? = null
    private fun put(r: Int, c: Int, cell: Cell) { rows.getOrPut(r) { TreeMap() }[c] = cell }
    fun text(r: Int, c: Int, s: String, style: Int = 0) = put(r, c, Cell(s, null, style))
    fun num(r: Int, c: Int, v: Double, style: Int = 0) = put(r, c, Cell(null, v, style))
    fun blank(r: Int, c: Int, style: Int = 0) = put(r, c, Cell(null, null, style))
}

class XWorkbook {
    private val styles = arrayListOf(XStyle())
    val sheets = ArrayList<XSheet>()
    fun style(font: Int = 0, fill: Int = 0, dec: Int = -1, border: Boolean = false, align: String = ""): Int {
        val s = XStyle(font, fill, dec, border, align)
        val i = styles.indexOf(s)
        if (i >= 0) return i
        styles.add(s); return styles.size - 1
    }
    fun addSheet(name: String): XSheet = XSheet(name).also { sheets.add(it) }

    companion object {
        // fonts: 0 normal, 1 bold white, 2 title, 3 italic blue, 4 grey small, 5 bold
        const val F_NORMAL = 0; const val F_WHITE_B = 1; const val F_TITLE = 2; const val F_UNIT = 3; const val F_META = 4; const val F_BOLD = 5
        // fills: 0 none, 1 gray125(reserved), 2 header, 3 group, 4 unit, 5 yellow, 6 orange, 7 red, 8 zebra
        const val FILL_HDR = 2; const val FILL_GRP = 3; const val FILL_UNIT = 4; const val FILL_YEL = 5; const val FILL_ORG = 6; const val FILL_RED = 7; const val FILL_ZEB = 8

        fun colName(c: Int): String {
            var n = c; val sb = StringBuilder()
            while (n > 0) { val m = (n - 1) % 26; sb.insert(0, ('A' + m)); n = (n - 1) / 26 }
            return sb.toString()
        }
        fun esc(s: String): String {
            val sb = StringBuilder()
            for (ch in s) {
                when {
                    ch == '&' -> sb.append("&amp;")
                    ch == '<' -> sb.append("&lt;")
                    ch == '>' -> sb.append("&gt;")
                    ch == '"' -> sb.append("&quot;")
                    ch.code < 32 && ch != '\n' && ch != '\t' -> Unit
                    else -> sb.append(ch)
                }
            }
            return sb.toString()
        }
        private fun numFmtId(dec: Int) = when (dec) { -1 -> 0; 0 -> 1; 1 -> 165; 2 -> 2; 3 -> 166; else -> 167 }
    }

    private fun stylesXml(): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        sb.append("<numFmts count=\"3\"><numFmt numFmtId=\"165\" formatCode=\"0.0\"/><numFmt numFmtId=\"166\" formatCode=\"0.000\"/><numFmt numFmtId=\"167\" formatCode=\"0.0000\"/></numFmts>")
        sb.append("<fonts count=\"6\">")
        sb.append("<font><sz val=\"11\"/><name val=\"Calibri\"/></font>")
        sb.append("<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font>")
        sb.append("<font><b/><sz val=\"16\"/><color rgb=\"FF1F3864\"/><name val=\"Calibri\"/></font>")
        sb.append("<font><i/><sz val=\"11\"/><color rgb=\"FF1F3864\"/><name val=\"Calibri\"/></font>")
        sb.append("<font><sz val=\"10\"/><color rgb=\"FF595959\"/><name val=\"Calibri\"/></font>")
        sb.append("<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>")
        val fills = listOf(null, null, "1F3864", "2F5597", "D9E2F3", "FFF2A8", "F8CBAD", "FF9B9B", "F5F8FC")
        sb.append("<fills count=\"${fills.size}\">")
        fills.forEachIndexed { i, f ->
            when {
                i == 0 -> sb.append("<fill><patternFill patternType=\"none\"/></fill>")
                i == 1 -> sb.append("<fill><patternFill patternType=\"gray125\"/></fill>")
                else -> sb.append("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF$f\"/><bgColor indexed=\"64\"/></patternFill></fill>")
            }
        }
        sb.append("</fills><borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border>")
        sb.append("<border><left style=\"thin\"><color rgb=\"FFBFC8D6\"/></left><right style=\"thin\"><color rgb=\"FFBFC8D6\"/></right><top style=\"thin\"><color rgb=\"FFBFC8D6\"/></top><bottom style=\"thin\"><color rgb=\"FFBFC8D6\"/></bottom><diagonal/></border></borders>")
        sb.append("<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>")
        sb.append("<cellXfs count=\"${styles.size}\">")
        for (s in styles) {
            sb.append("<xf numFmtId=\"${numFmtId(s.dec)}\" fontId=\"${s.font}\" fillId=\"${s.fill}\" borderId=\"${if (s.border) 1 else 0}\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"")
            if (s.align.isNotEmpty()) sb.append(" applyAlignment=\"1\"><alignment horizontal=\"${s.align}\" vertical=\"center\"/></xf>") else sb.append("/>")
        }
        sb.append("</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>")
        return sb.toString()
    }

    private fun sheetXml(sh: XSheet): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        sb.append("<sheetViews><sheetView showGridLines=\"0\" workbookViewId=\"0\">")
        if (sh.freezeRow > 0 || sh.freezeCol > 0) {
            val tl = colName(sh.freezeCol + 1) + (sh.freezeRow + 1)
            sb.append("<pane")
            if (sh.freezeCol > 0) sb.append(" xSplit=\"${sh.freezeCol}\"")
            if (sh.freezeRow > 0) sb.append(" ySplit=\"${sh.freezeRow}\"")
            val pane = if (sh.freezeCol > 0 && sh.freezeRow > 0) "bottomRight" else if (sh.freezeRow > 0) "bottomLeft" else "topRight"
            sb.append(" topLeftCell=\"$tl\" activePane=\"$pane\" state=\"frozen\"/><selection pane=\"$pane\"/>")
        }
        sb.append("</sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/>")
        if (sh.widths.isNotEmpty()) {
            sb.append("<cols>")
            for ((c, w) in sh.widths.toSortedMap()) sb.append("<col min=\"$c\" max=\"$c\" width=\"$w\" customWidth=\"1\"/>")
            sb.append("</cols>")
        }
        sb.append("<sheetData>")
        for ((r, cells) in sh.rows) {
            sb.append("<row r=\"$r\"")
            sh.heights[r]?.let { sb.append(" ht=\"$it\" customHeight=\"1\"") }
            sb.append(">")
            for ((c, cell) in cells) {
                val ref = colName(c) + r
                when {
                    cell.n != null -> sb.append("<c r=\"$ref\" s=\"${cell.style}\"><v>${cell.n}</v></c>")
                    cell.s != null -> sb.append("<c r=\"$ref\" s=\"${cell.style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(cell.s)}</t></is></c>")
                    else -> sb.append("<c r=\"$ref\" s=\"${cell.style}\"/>")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData>")
        sh.filter?.let { sb.append("<autoFilter ref=\"$it\"/>") }
        if (sh.merges.isNotEmpty()) {
            sb.append("<mergeCells count=\"${sh.merges.size}\">")
            for (m in sh.merges) sb.append("<mergeCell ref=\"$m\"/>")
            sb.append("</mergeCells>")
        }
        sb.append("</worksheet>")
        return sb.toString()
    }

    fun write(out: OutputStream) {
        ZipOutputStream(out).use { z ->
            fun put(name: String, body: String) { z.putNextEntry(ZipEntry(name)); z.write(body.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            val ct = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>")
            sheets.indices.forEach { ct.append("<Override PartName=\"/xl/worksheets/sheet${it + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>") }
            ct.append("</Types>")
            put("[Content_Types].xml", ct.toString())
            put("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            val wb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>")
            sheets.forEachIndexed { i, s -> wb.append("<sheet name=\"${esc(s.name)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>") }
            wb.append("</sheets></workbook>")
            put("xl/workbook.xml", wb.toString())
            val rel = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">")
            sheets.indices.forEach { rel.append("<Relationship Id=\"rId${it + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${it + 1}.xml\"/>") }
            rel.append("<Relationship Id=\"rId${sheets.size + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>")
            put("xl/_rels/workbook.xml.rels", rel.toString())
            put("xl/styles.xml", stylesXml())
            sheets.forEachIndexed { i, s -> put("xl/worksheets/sheet${i + 1}.xml", sheetXml(s)) }
        }
    }
}
