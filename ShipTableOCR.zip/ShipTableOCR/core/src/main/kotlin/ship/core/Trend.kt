package ship.core

import kotlin.math.abs

/**
 * Trend sanity check for one numeric column (values in table order).
 * Normal series: rising, falling, rising→falling, falling→rising, with plateaus (unchanged values) anywhere.
 * Abnormal (flagged red): a *short* run that goes against an established trend and then returns to it
 * ("falling, falling, … 3 points up, falling again"), or an isolated spike far outside the local step size.
 */
object Trend {
    private class Run(val dir: Int, val first: Int, var last: Int, var steps: Int, val flatsBefore: Int)

    fun reversals(xs: List<Double>, dec: Int, maxShort: Int = 3, minSide: Int = 5, maxGap: Int = 1): List<IntRange> {
        val eps = 1.5 * Math.pow(10.0, -dec.toDouble())
        val runs = ArrayList<Run>()
        var flats = 0
        for (i in 1 until xs.size) {
            val d = xs[i] - xs[i - 1]
            val s = if (d > eps) 1 else if (d < -eps) -1 else 0
            if (s == 0) { flats++; continue }
            val lastRun = runs.lastOrNull()
            if (lastRun != null && lastRun.dir == s && flats <= maxGap) { lastRun.last = i; lastRun.steps++ }
            else runs.add(Run(s, lastRun?.last ?: (i - 1), i, 1, flats))
            flats = 0
        }
        val out = ArrayList<IntRange>()
        for (k in 1 until runs.size - 1) {
            val r = runs[k]; val a = runs[k - 1]; val b = runs[k + 1]
            if (r.steps <= maxShort && a.dir == -r.dir && b.dir == -r.dir &&
                a.steps >= minSide && b.steps >= minSide && r.flatsBefore <= maxGap && b.flatsBefore <= maxGap)
                out.add(r.first..r.last)
        }
        return out
    }

    fun spikes(xs: List<Double>, dec: Int, k: Double = 8.0, minUnits: Int = 10, win: Int = 8): List<Int> {
        val n = xs.size
        val u = Math.pow(10.0, -dec.toDouble())
        val out = ArrayList<Int>()
        for (i in 1 until n - 1) {
            val a = xs[i] - xs[i - 1]; val b = xs[i] - xs[i + 1]
            if (a * b <= 0) continue
            val exc = minOf(abs(a), abs(b))
            val lo = maxOf(1, i - win); val hi = minOf(n - 1, i + win)
            val steps = (lo..hi).filter { it != i && it != i + 1 }.map { abs(xs[it] - xs[it - 1]) }.sorted()
            val med = if (steps.isEmpty()) 0.0 else steps[steps.size / 2]
            if (exc >= minUnits * u && exc >= k * med) out.add(i)
        }
        return out
    }

    /** index (into [xs]) → reason */
    fun anomalies(xs: List<Double>, dec: Int): Map<Int, String> {
        val m = LinkedHashMap<Int, String>()
        for (i in spikes(xs, dec)) m[i] = "孤立尖峰:与前后数据趋势明显不符"
        for (r in reversals(xs, dec)) for (i in r) m.putIfAbsent(i, "趋势异常:连续变化中突然反向 ${r.last - r.first} 步后又恢复")
        return m
    }
}
