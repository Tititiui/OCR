package ship.core

object Parsers {
    private val volRe = Regex("Volume\\s*in\\s*m", RegexOption.IGNORE_CASE)
    private val nameVolRe = Regex("^\\s*(.+?)\\s*-\\s*Volume\\s*in\\s*m", RegexOption.IGNORE_CASE)
    private val compRe = Regex("^\\s*(\\d+)\\s+compart\\w*\\s*[:;]\\s*(.+?)\\s*$", RegexOption.IGNORE_CASE)
    private val identRe = Regex("^\\s*Compartment\\s*ident\\s*[:;]\\s*(.+?)\\s*$", RegexOption.IGNORE_CASE)
    private val contentsRe = Regex("^\\s*Contents\\s*[:;]\\s*(.+?)\\s*$", RegexOption.IGNORE_CASE)
    private val extremeRe = Regex("^\\s*(Extreme\\s*points|Aft\\s*end|Fore\\s*end)", RegexOption.IGNORE_CASE)
    private val deviceRe = Regex("^\\s*(Sounding\\s*device|[xyz]\\s*=)", RegexOption.IGNORE_CASE)
    private val trimRe = Regex("Trim\\s*=\\s*(-?[\\d.]+)", RegexOption.IGNORE_CASE)
    private val intRe = Regex("\\d+")

    fun isSoundingRow(l: TextLine): Boolean {
        val w = l.words
        if (w.size < 4) return false
        val a = Numbers.normalize(w[0].text); val b = Numbers.normalize(w[1].text)
        if (!intRe.matches(a) || !intRe.matches(b)) return false
        return Numbers.normalize(w.drop(2).joinToString("") { it.text }).contains('.')
    }

    fun isHydroRow(l: TextLine): Boolean {
        val w = l.words
        if (w.size < 8) return false
        return Regex("^\\d+\\.\\d{3}$").matches(Numbers.normalize(w[0].text))
    }

    fun classify(lines: List<TextLine>): DocKind? {
        val all = lines.joinToString("\n") { it.text }.uppercase()
        val s = (all.contains("GAUGE") && all.contains("ULL")) || all.contains("VOLUME IN M") || all.contains("SOUNDING")
        val h = (all.contains("VOLM") && all.contains("DISP")) || Regex("TRIM\\s*=").containsMatchIn(all) || all.contains("LOADING MANUAL")
        if (s && !h) return DocKind.SOUNDING
        if (h && !s) return DocKind.HYDRO
        val ns = lines.count { isSoundingRow(it) }
        val nh = lines.count { isHydroRow(it) }
        return when {
            ns == 0 && nh == 0 -> null
            ns >= nh -> DocKind.SOUNDING
            else -> DocKind.HYDRO
        }
    }

    private fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    fun sounding(pages: List<PageContent>, issues: MutableList<Issue>): List<Table> {
        val tables = LinkedHashMap<String, Table>()
        var cur: Table? = null
        for (p in pages) {
            val texts = p.lines.map { it.text }
            val hasVol = texts.any { volRe.containsMatchIn(it) }
            val dataLines = p.lines.filter { isSoundingRow(it) }
            if (!hasVol && !(dataLines.size >= 3 && cur != null)) continue
            val meta = Meta()
            var hdrName: String? = null
            var nameLine: String? = null
            for (t in texts) {
                compRe.find(t)?.let { meta.no = it.groupValues[1]; hdrName = it.groupValues[2].trim() }
                identRe.find(t)?.let { meta.ident = it.groupValues[1] }
                contentsRe.find(t)?.let { meta.contents = it.groupValues[1] }
                nameVolRe.find(t)?.let { nameLine = it.groupValues[1].trim() }
                if (extremeRe.containsMatchIn(t)) meta.extreme.add(t.trim())
                if (deviceRe.containsMatchIn(t)) meta.device.add(t.trim())
            }
            val hdr = hdrName
            val nl = nameLine
            var name = hdr ?: nl ?: cur?.name
            if (name == null) { issues.add(Issue("-", p.page, "页", "未找到舱名,该页已跳过")); continue }
            if (hdr != null && nl != null && hdr != nl)
                issues.add(Issue(hdr, p.page, "舱名", "页眉「$hdr」与表头「$nl」读数不一致,采用页眉"))
            if (hdr == null && cur != null && nl != null && nl != cur.name && lev(nl, cur.name) <= 2) name = cur.name
            val table: Table
            if (hdr != null || !tables.containsKey(name)) {
                var key = name
                var k = 2
                while (tables.containsKey(key)) { key = "$name#$k"; k++ }
                table = Table(key, meta); tables[key] = table
            } else table = tables[name]!!
            cur = table
            table.pages.add(p.page)
            val anchors = if (p.ocr) Numbers.anchors(dataLines, Schemas.sounding) else null
            for (l in dataLines) {
                val r = Numbers.parseRow(l, Schemas.sounding, Schemas.SOUNDING_INT_LEAD, anchors, p.page)
                if (r.v == null) issues.add(Issue(table.name, p.page, "行", "整行无法解析: " + l.text.take(60)))
                table.rows.add(r)
            }
        }
        return tables.values.toList()
    }

    private fun headerOf(l: TextLine, ocr: Boolean): List<String>? {
        val t = l.words.map { it.text }
        if (t.size < 5) return null
        val known = Schemas.hydroInfo.keys
        val mapped = t.map { w ->
            val u = w.uppercase()
            if (u in known) u else if (ocr && u.length >= 2) known.firstOrNull { it.length >= 2 && lev(u, it) <= 1 } else null
        }
        return if (mapped.firstOrNull() == "T" && mapped.count { it != null } >= 4 && mapped.all { it != null }) mapped.filterNotNull() else null
    }

    private fun colsFor(labels: List<String>) = labels.map { Col(it, it, Schemas.hydroInfo[it]?.second ?: "", Schemas.hydroInfo[it]?.first ?: 2, "") }

    /**
     * Header-driven: each page carries its own header; blocks with different headers (e.g. "T VOLM DISP … KML" on pages 1-6 and
     * "T LWL WLA … CM" on pages 7-12) are merged into ONE table on the T value.
     */
    fun hydro(pages: List<PageContent>, issues: MutableList<Issue>): Table {
        val blocks = LinkedHashMap<List<String>, LinkedHashMap<Double, Pair<Int, Array<Double?>>>>()
        val trims = LinkedHashSet<String>()
        var labels: List<String>? = null
        for (p in pages) {
            val dataLines = p.lines.filter { isHydroRow(it) }
            if (dataLines.isEmpty()) continue
            for (l in p.lines) headerOf(l, p.ocr)?.let { labels = it; blocks.getOrPut(it) { LinkedHashMap() } }
            val lab = labels
            if (lab == null) { issues.add(Issue("静水力", p.page, "页", "未找到表头,该页已跳过")); continue }
            val cols = colsFor(lab)
            val anchors = if (p.ocr) Numbers.anchors(dataLines.filter { it.words.size == cols.size }, cols) else null
            for (l in p.lines) {
                trimRe.find(l.text)?.let { trims.add(it.groupValues[1]) }
                if (!isHydroRow(l)) continue
                val r = Numbers.parseRow(l, cols, 0, anchors, p.page)
                val v = r.v
                if (v == null || v[0] == null) { issues.add(Issue("静水力", p.page, "行", "整行无法解析: " + l.text.take(70))); continue }
                blocks.getValue(lab)[Math.round(v[0]!! * 1000) / 1000.0] = p.page to v
            }
        }
        val all = ArrayList<String>()
        for (b in blocks.keys) for (c in b) if (c !in all) all.add(c)
        val keys = blocks.values.flatMap { it.keys }.toSortedSet()
        val meta = Meta().also { it.contents = if (trims.isEmpty()) null else "Trim = " + trims.joinToString(", ") + " m" }
        val t = Table("静水力参数", meta, colsFor(all))
        for (k in keys) {
            val row = arrayOfNulls<Double>(all.size)
            var pg = 0
            for ((b, rows) in blocks) {
                val hit = rows[k] ?: continue
                if (pg == 0) pg = hit.first
                b.forEachIndexed { j, c -> val ix = all.indexOf(c); if (row[ix] == null) row[ix] = hit.second.getOrNull(j) }
            }
            t.rows.add(Row(pg, row, ""))
            if (pg !in t.pages) t.pages.add(pg)
        }
        return t
    }
}
