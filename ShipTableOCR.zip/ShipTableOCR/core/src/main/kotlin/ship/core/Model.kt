package ship.core

class Meta {
    var no: String? = null
    var ident: String? = null
    var contents: String? = null
    val extreme = ArrayList<String>()
    val device = ArrayList<String>()
}

/** [v]==null → the whole line could not be read. A null cell inside [v] = that cell missing/unreadable. */
class Row(val page: Int, val v: Array<Double?>?, val raw: String, val trim: Double? = null)

class Table(val name: String, val meta: Meta, var cols: List<Col>? = null) {
    val pages = ArrayList<Int>()
    val rows = ArrayList<Row>()
}

class Issue(val where: String, val page: Int, val pos: String, val msg: String)

/** Content of one PDF page after text-layer extraction or OCR + line building. */
class PageContent(val page: Int, val lines: List<TextLine>, val ocr: Boolean)
