package ship.core

import kotlin.math.abs

object Numbers {
    private val subst = mapOf(
        'O' to '0', 'o' to '0', 'Q' to '0', 'D' to '0', 'l' to '1', 'I' to '1', '|' to '1', 'i' to '1',
        'S' to '5', 's' to '5', 'B' to '8', 'Z' to '2', 'z' to '2', ',' to '.', '—' to '-', '–' to '-', '−' to '-'
    )

    /** Keep only digits, '.', '-' after fixing the usual OCR look-alikes (O→0, l→1, ','→'.' ...). */
    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            val c = subst[ch] ?: ch
            if (c.isDigit() || c == '.' || c == '-') sb.append(c)
        }
        return sb.toString()
    }

    private val fmt = HashMap<Int, Regex>()
    fun fmtRegex(dec: Int): Regex = fmt.getOrPut(dec) {
        if (dec == 0) Regex("^-?\\d+") else Regex("^-?\\d+\\.\\d{$dec}")
    }

    class Seg(val vals: List<Double>, val ok: Boolean)

    /**
     * Split a de-spaced numeric string into numbers using each column's fixed decimals.
     * "170.80-10.00" → 170.80, -10.00.  Fewer numbers than columns is accepted if the string ends cleanly
     * (right edge of the scan cut off) — the caller sees the shorter list.
     */
    fun segment(s: String, cols: List<Col>): Seg {
        var pos = 0
        val out = ArrayList<Double>()
        for (c in cols) {
            if (pos >= s.length) return Seg(out, true)
            val m = fmtRegex(c.dec).find(s.substring(pos)) ?: return Seg(out, false)
            out.add(m.value.toDouble())
            pos += m.value.length
        }
        return Seg(out, pos == s.length)
    }

    /** Repair a single cell: all digits but no decimal point → insert it; otherwise null. */
    fun repair(n: String, dec: Int): Double? {
        if (fmtRegex(dec).matchEntire(n) != null) return n.toDouble()
        if (dec > 0 && n.matches(Regex("-?\\d{${dec + 1},}"))) {
            val neg = n.startsWith("-")
            val d = n.removePrefix("-")
            return ((if (neg) "-" else "") + d.substring(0, d.length - dec) + "." + d.substring(d.length - dec)).toDouble()
        }
        return null
    }

    /** Right-edge x of each column, learned from lines whose token count equals the column count. */
    fun anchors(lines: List<TextLine>, cols: List<Col>): DoubleArray? {
        val per = List(cols.size) { ArrayList<Double>() }
        var n = 0
        for (l in lines) {
            if (l.words.size != cols.size) continue
            val ok = l.words.indices.all { i -> fmtRegex(cols[i].dec).matchEntire(normalize(l.words[i].text)) != null }
            if (!ok) continue
            n++
            l.words.forEachIndexed { i, w -> per[i].add(w.xr.toDouble()) }
        }
        if (n < 3) return null
        return DoubleArray(cols.size) { i -> per[i].sorted()[per[i].size / 2] }
    }

    private fun byAnchors(line: TextLine, cols: List<Col>, a: DoubleArray): Array<Double?>? {
        val gap = a.toList().zipWithNext { x, y -> y - x }.minOrNull() ?: return null
        val out = arrayOfNulls<Double>(cols.size)
        var hit = 0
        for (w in line.words) {
            var best = 0; var bd = Double.MAX_VALUE
            for (i in a.indices) { val d = abs(a[i] - w.xr); if (d < bd) { bd = d; best = i } }
            if (bd > gap * 0.6) continue
            val v = repair(normalize(w.text), cols[best].dec)
            if (v != null && out[best] == null) { out[best] = v; hit++ }
        }
        return if (hit >= cols.size / 2) out else null
    }

    /** Parse one table line into a Row. [intLead] = number of leading integer columns separated by spaces. */
    fun parseRow(line: TextLine, cols: List<Col>, intLead: Int, anchors: DoubleArray?, page: Int, trim: Double? = null): Row {
        val toks = line.words.map { it.text }
        val lead = toks.take(intLead).map { normalize(it) }
        if (toks.size >= intLead && lead.all { it.matches(Regex("\\d+")) }) {
            val rest = normalize(toks.drop(intLead).joinToString(""))
            val seg = segment(rest, cols.drop(intLead))
            if (seg.ok) {
                val arr = arrayOfNulls<Double>(cols.size)
                lead.forEachIndexed { i, s -> arr[i] = s.toDouble() }
                seg.vals.forEachIndexed { i, d -> arr[intLead + i] = d }
                return Row(page, arr, line.text, trim)
            }
        }
        if (anchors != null) byAnchors(line, cols, anchors)?.let { return Row(page, it, line.text, trim) }
        return Row(page, null, line.text, trim)
    }
}
