package ship.core

/**
 * Offline, classical watermark removal for scanned / rendered pages (ARGB int pixels).
 *
 * Idea: table text is near-black and neutral; stamps/watermarks are light grey or coloured and rarely
 * touch the ink. So: (1) find the ink threshold automatically (Otsu between black ink and grey stamp),
 * (2) keep ink + a 2 px anti-aliasing ring untouched, (3) whiten every other non-white pixel,
 * (4) inside the ring fade faint grey (stamp crossing a digit) towards white.
 * Nothing else on the page is modified, so the original is preserved as much as possible.
 */
object Watermark {
    class Report(val score: Double, val likely: Boolean)

    private fun lum(p: Int): Int = (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000
    private fun chroma(p: Int): Int {
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        return maxOf(r, g, b) - minOf(r, g, b)
    }

    fun inkThreshold(px: IntArray): Int {
        val h = IntArray(200)
        for (p in px) { val l = lum(p); if (l < 200) h[l]++ }
        val total = h.sum().toDouble()
        if (total < 100) return 105
        var sum = 0.0
        for (i in 0 until 200) sum += i * h[i]
        var wB = 0.0; var sumB = 0.0; var best = 105; var bestV = -1.0
        for (t in 0 until 200) {
            wB += h[t]; if (wB == 0.0) continue
            val wF = total - wB; if (wF == 0.0) break
            sumB += t * h[t]
            val mB = sumB / wB; val mF = (sum - sumB) / wF
            val v = wB * wF * (mB - mF) * (mB - mF)
            if (v > bestV) { bestV = v; best = t }
        }
        return best.coerceIn(70, 130)
    }

    private fun dilate(m: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val tmp = BooleanArray(w * h)
        for (y in 0 until h) {
            val o = y * w
            var d = Int.MAX_VALUE / 2
            for (x in 0 until w) { d = if (m[o + x]) 0 else d + 1; if (d <= r) tmp[o + x] = true }
            d = Int.MAX_VALUE / 2
            for (x in w - 1 downTo 0) { d = if (m[o + x]) 0 else d + 1; if (d <= r) tmp[o + x] = true }
        }
        val out = BooleanArray(w * h)
        for (x in 0 until w) {
            var d = Int.MAX_VALUE / 2
            for (y in 0 until h) { d = if (tmp[y * w + x]) 0 else d + 1; if (d <= r) out[y * w + x] = true }
            d = Int.MAX_VALUE / 2
            for (y in h - 1 downTo 0) { d = if (tmp[y * w + x]) 0 else d + 1; if (d <= r) out[y * w + x] = true }
        }
        return out
    }

    private fun inkMask(px: IntArray, thr: Int): BooleanArray = BooleanArray(px.size) { lum(px[it]) < thr && chroma(px[it]) <= 60 }

    /** Share of isolated mid-grey / coloured "ghost" pixels relative to ink. >~1 % ⇒ a stamp/watermark is present. */
    fun detect(px: IntArray, w: Int, h: Int): Report {
        val thr = inkThreshold(px)
        val ink = inkMask(px, thr)
        val prot = dilate(ink, w, h, 3)
        var inkN = 0; var ghost = 0
        for (i in px.indices) {
            if (ink[i]) inkN++
            else if (!prot[i]) { val l = lum(px[i]); if (l in 120..225) ghost++ }
        }
        val s = ghost.toDouble() / maxOf(inkN, 1)
        return Report(s, s > 0.01)
    }

    /** In-place removal. Returns number of pixels changed. */
    fun remove(px: IntArray, w: Int, h: Int, protect: Int = 2): Int {
        val thr = inkThreshold(px)
        val ink = inkMask(px, thr)
        val prot = dilate(ink, w, h, protect)
        var changed = 0
        for (i in px.indices) {
            if (ink[i]) continue
            val p = px[i]; val l = lum(p)
            if (!prot[i]) {
                if (l < 245) { px[i] = -1; changed++ }          // 0xFFFFFFFF opaque white
            } else {
                val st = ((l - thr).toFloat() / (200 - thr)).coerceIn(0f, 1f)
                if (st > 0f) {
                    val r = (((p shr 16) and 255) * (1 - st) + 255 * st).toInt()
                    val g = (((p shr 8) and 255) * (1 - st) + 255 * st).toInt()
                    val b = ((p and 255) * (1 - st) + 255 * st).toInt()
                    px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b; changed++
                }
            }
        }
        return changed
    }
}
