package ship.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** A raw OCR word box in page pixels. */
class OcrWord(val text: String, val l: Float, val t: Float, val r: Float, val b: Float)

/** Word after de-skew: [xl]/[xr] = left/right edge, [yc] = vertical centre in the straightened frame. */
class PW(val text: String, val xl: Float, val xr: Float, val yc: Float, val h: Float)

class TextLine(val words: List<PW>) {
    val text: String get() = words.joinToString(" ") { it.text }

    companion object {
        /** Build a line from plain text (text-layer PDFs). Positions are character columns. */
        fun fromString(s: String): TextLine {
            val out = ArrayList<PW>()
            var i = 0
            while (i < s.length) {
                if (s[i].isWhitespace()) { i++; continue }
                var j = i
                while (j < s.length && !s[j].isWhitespace()) j++
                out.add(PW(s.substring(i, j), i.toFloat(), j.toFloat(), 0f, 1f))
                i = j
            }
            return TextLine(out)
        }
    }
}

object LineBuilder {
    /** Page skew (degrees) that makes the text rows sharpest. Scans/photos are often 0.3–2° off. */
    fun estimateSkew(words: List<OcrWord>): Double {
        if (words.size < 20) return 0.0
        val hs = words.map { it.b - it.t }.sorted()
        val mh = hs[hs.size / 2].coerceAtLeast(4f)
        val bin = mh / 2f
        var best = 0.0
        var bestScore = -1.0
        var a = -3.0
        while (a <= 3.0001) {
            val th = Math.toRadians(a)
            val c = cos(th); val s = sin(th)
            val hist = HashMap<Int, Int>()
            for (w in words) {
                val x = (w.l + w.r) / 2f; val y = (w.t + w.b) / 2f
                val yy = -x * s + y * c
                val k = Math.floor((yy / bin).toDouble()).toInt()
                hist[k] = (hist[k] ?: 0) + 1
            }
            var score = 0.0
            for (v in hist.values) score += v.toDouble() * v
            if (score > bestScore) { bestScore = score; best = a }
            a += 0.25
        }
        return best
    }

    fun build(words: List<OcrWord>): List<TextLine> {
        if (words.isEmpty()) return emptyList()
        val skew = estimateSkew(words)
        val th = Math.toRadians(skew)
        val c = cos(th).toFloat(); val s = sin(th).toFloat()
        val pw = words.map { w ->
            val xl = w.l * c + ((w.t + w.b) / 2f) * s
            val xr = w.r * c + ((w.t + w.b) / 2f) * s
            val yc = -((w.l + w.r) / 2f) * s + ((w.t + w.b) / 2f) * c
            PW(w.text, xl, xr, yc, w.b - w.t)
        }.sortedBy { it.yc }
        val hs = pw.map { it.h }.sorted()
        val tol = hs[hs.size / 2] * 0.6f
        val lines = ArrayList<MutableList<PW>>()
        var mean = 0f
        for (w in pw) {
            if (lines.isEmpty() || abs(w.yc - mean) > tol) {
                lines.add(mutableListOf(w)); mean = w.yc
            } else {
                val cur = lines.last(); cur.add(w)
                mean = cur.map { it.yc }.average().toFloat()
            }
        }
        return lines.map { l -> TextLine(l.sortedBy { it.xl }) }
    }
}
