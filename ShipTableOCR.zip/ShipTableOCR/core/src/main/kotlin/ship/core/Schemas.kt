package ship.core

/** One table column. [dec] = fixed number of decimals printed in the source (this is what makes glued/odd tokens repairable). */
data class Col(val key: String, val label: String, val unit: String, val dec: Int, val group: String = "")

enum class DocKind { SOUNDING, HYDRO }

object Schemas {
    val sounding: List<Col> = buildList {
        add(Col("gauge", "GAUGE", "cm", 0, "测深 Sounding"))
        add(Col("ull", "ULL", "cm", 0, "测深 Sounding"))
        for (t in listOf("0", "-0.5", "-1", "-1.5", "-2", "-2.5", "-3", "-3.5", "-4", "0.5", "1"))
            add(Col("tr$t", "tr=$t", "m³", 2, "纵倾下容积 Volume by trim (m)"))
        for (h in listOf("HC3P", "HC2P", "HC1P", "HC3S", "HC2S", "HC1S"))
            add(Col(h, h, "m³", 2, "横倾容积 Heel volume"))
        add(Col("fill", "FILL", "%", 1, "充满度"))
        add(Col("lcg", "L.C.G", "m", 2, "重心 CG"))
        add(Col("tcg", "T.C.G", "m", 2, "重心 CG"))
        add(Col("vcg", "V.C.G", "m", 2, "重心 CG"))
        add(Col("imom", "IMOM", "m⁴", 1, "自由液面惯性矩"))
    }
    const val SOUNDING_INT_LEAD = 2

    val hydro: List<Col> = listOf(
        Col("T", "T", "m", 3), Col("TK", "TK", "m", 3), Col("VOLM", "VOLM", "m³", 1), Col("DISP", "DISP", "t", 1),
        Col("LCA", "LCA", "m", 3), Col("CB", "CB", "", 4), Col("LCB", "LCB", "m", 3), Col("VCB", "VCB", "m", 3),
        Col("KMT", "KMT", "m", 3), Col("KML", "KML", "m", 3), Col("DISF", "DISF", "t", 1), Col("LWL", "LWL", "m", 2),
        Col("WLA", "WLA", "m²", 1), Col("AREA", "AREA", "m²", 1), Col("TCP", "TCP", "t/cm", 1),
        Col("MCT", "MCT", "tm/cm", 1), Col("CW", "CW", "", 4), Col("CP", "CP", "", 4), Col("CM", "CM", "", 4)
    )

    /** Hydrostatic labels seen in real manuals → (decimals, unit). Unknown labels are inferred from the data. */
    val hydroInfo: Map<String, Pair<Int, String>> = mapOf(
        "T" to (3 to "m"), "TK" to (3 to "m"), "VOLM" to (1 to "m³"), "DISP" to (1 to "t"), "LCA" to (3 to "m"),
        "CB" to (4 to ""), "LCB" to (3 to "m"), "VCB" to (3 to "m"), "KMT" to (3 to "m"), "KML" to (3 to "m"),
        "DISF" to (1 to "t"), "LWL" to (2 to "m"), "WLA" to (1 to "m²"), "AREA" to (1 to "m²"), "WSA" to (1 to "m²"),
        "TCP" to (1 to "t/cm"), "MCT" to (1 to "tm/cm"), "CW" to (4 to ""), "CP" to (4 to ""), "CM" to (4 to "")
    )
}
