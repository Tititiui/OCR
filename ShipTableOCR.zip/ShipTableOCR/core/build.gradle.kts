// Pure JVM module: no Android classes. Reused as-is by the future Windows (Compose Desktop / JVM) app.
plugins { id("org.jetbrains.kotlin.jvm") }
kotlin { jvmToolchain(17) }
dependencies { testImplementation(kotlin("test")) }
tasks.test { useJUnitPlatform() }
