import re
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import ship_tables as st

HDR=PatternFill("solid",fgColor="1F3864"); GRP=PatternFill("solid",fgColor="2F5597"); UNIT=PatternFill("solid",fgColor="D9E2F3")
YEL=PatternFill("solid",fgColor="FFF2A8"); ORG=PatternFill("solid",fgColor="F8CBAD"); RED=PatternFill("solid",fgColor="FF9B9B"); ZEB=PatternFill("solid",fgColor="F5F8FC")
thin=Side(style="thin",color="BFC8D6"); BOX=Border(left=thin,right=thin,top=thin,bottom=thin)

def safe_sheet(name, used):
    n=re.sub(r"[:\\/?*\[\]]","-",name).strip()[:31] or "Sheet"
    base=n; k=2
    while n.lower() in used: n=(base[:28]+f"_{k}"); k+=1
    used.add(n.lower()); return n

def write_table(ws, title, meta_lines, cols, rows, flags, fixed, anoms=None):
    anoms=anoms or {}
    ws.sheet_view.showGridLines=False
    ws["A1"]=title; ws["A1"].font=Font(size=16,bold=True,color="1F3864")
    r=2
    for m in meta_lines:
        ws.cell(r,1,m).font=Font(size=10,color="595959"); r+=1
    r+=1; grp_row=r; hdr_row=r+1; unit_row=r+2; data0=r+3
    # group header (merged runs)
    c=0
    while c<len(cols):
        g=cols[c][4]; e=c
        while e+1<len(cols) and cols[e+1][4]==g: e+=1
        cell=ws.cell(grp_row,c+1,g if g else None); cell.fill=GRP; cell.font=Font(bold=True,color="FFFFFF"); cell.alignment=Alignment(horizontal="center")
        for k in range(c,e+1): ws.cell(grp_row,k+1).fill=GRP
        if e>c: ws.merge_cells(start_row=grp_row,start_column=c+1,end_row=grp_row,end_column=e+1)
        c=e+1
    for i,(k,label,unit,dec,g) in enumerate(cols):
        h=ws.cell(hdr_row,i+1,label); h.fill=HDR; h.font=Font(bold=True,color="FFFFFF"); h.alignment=Alignment(horizontal="center"); h.border=BOX
        u=ws.cell(unit_row,i+1,unit); u.fill=UNIT; u.font=Font(italic=True,color="1F3864"); u.alignment=Alignment(horizontal="center"); u.border=BOX
        ws.column_dimensions[get_column_letter(i+1)].width=max(9,len(label)+3, 11 if dec>=2 else 9)
    for ri,vals in enumerate(rows):
        for ci in range(len(cols)):
            cell=ws.cell(data0+ri,ci+1)
            if vals is not None:
                cell.value=vals[ci]
                d=cols[ci][3]; cell.number_format="0" if d==0 else "0."+"0"*d
            cell.border=BOX; cell.alignment=Alignment(horizontal="right")
            if ri%2==1: cell.fill=ZEB
            if vals is None: cell.fill=RED
            if (ri,ci) in fixed: cell.fill=ORG
            if (ri,ci) in flags: cell.fill=YEL
            if (ri,ci) in anoms: cell.fill=RED; cell.font=Font(bold=True,color="9C0006")
    ws.freeze_panes=ws.cell(data0,3 if len(cols)>19 else 2)
    ws.auto_filter.ref=f"A{hdr_row}:{get_column_letter(len(cols))}{data0+len(rows)-1}"
    ws.row_dimensions[hdr_row].height=20
    return data0

def build_sounding_xlsx(comps, path, source_name, issues_extra=()):
    wb=Workbook(); wb.remove(wb.active); used=set(); summary=[]; issues=list(issues_extra)
    for name,c in comps.items():
        vals,flags,notes=st.validate_sounding(c["rows"])
        fixed={(n[1], 0 if n[2]=="GAUGE" else 1) for n in notes}
        ws=wb.create_sheet(safe_sheet(name,used))
        m=c["meta"]
        meta=[f"Compartment ident: {m.get('ident','')}   |   {m.get('contents','')}",
              "   ".join(x for x in m.get("extreme",[]) ), "   ".join(m.get("device",[])),
              f"来源页: {c['pages'][0]}–{c['pages'][-1]}   行数: {len(vals)}   (Volume in m³)"]
        write_table(ws,name,meta,st.SOUNDING_COLS,vals,flags,fixed)
        nflag=len(flags); nbad=sum(1 for v in vals if v is None)
        for (r,cc),w in flags.items():
            issues.append((name,c["rows"][r][0],f"行{r+1} 列{st.SOUNDING_COLS[cc][1]}",w[0]))
        for n in notes: issues.append((name,n[0],f"行{n[1]+1} {n[2]}",f"已自动校正 {n[3]}"))
        for r,v in enumerate(vals):
            if v is None: issues.append((name,c["rows"][r][0],f"行{r+1}","整行无法解析"))
        summary.append((name,f"{c['pages'][0]}–{c['pages'][-1]}",len(vals),nbad,len(notes),nflag))
    write_report(wb,source_name,"测深表 Sounding Table",["舱名","来源页","行数","无法解析行","自动校正","可疑单元格"],summary,issues)
    wb.save(path); return summary,issues

def build_hydro_xlsx(rows, path, source_name, issues_extra=()):
    vals,flags,notes=st.validate_hydro(rows)
    wb=Workbook(); ws=wb.active; ws.title="静水力参数"
    pages=sorted({r[0] for r in rows}); trims=sorted({r[1] for r in rows if r[1] is not None})
    meta=[f"Trim = {', '.join(str(t) for t in trims)} m   |   来源页: {pages[0]}–{pages[-1]}   行数: {len(rows)}"]
    write_table(ws,"静水力参数表 Hydrostatic Table",meta,st.HYDRO_COLS,vals,flags,set())
    issues=list(issues_extra)
    for (r,c),w in flags.items(): issues.append(("静水力",rows[r][0],f"T={rows[r][2][0] if rows[r][2] else '?'} 列{st.HYDRO_COLS[c][0]}",w[0]))
    for r,v in enumerate(vals):
        if v is None: issues.append(("静水力",rows[r][0],f"行{r+1}","整行无法解析"))
    summary=[("静水力参数",f"{pages[0]}–{pages[-1]}",len(rows),sum(1 for v in vals if v is None),0,len(flags))]
    write_report(wb,source_name,"静水力参数 Hydrostatics",["表","来源页","行数","无法解析行","自动校正","可疑单元格"],summary,issues)
    wb.save(path); return summary,issues

def write_report(wb,source,kind,head,summary,issues):
    issues=[tuple(i) for i in issues]
    ws=wb.create_sheet("生成效果说明"); ws.sheet_view.showGridLines=False
    ws["A1"]="生成效果说明"; ws["A1"].font=Font(size=16,bold=True,color="1F3864")
    ws["A2"]=f"来源文件: {source}   类型: {kind}"; ws["A3"]="颜色: 红=趋势异常或无法识别(必须手动校对,见「待校对清单」) / 黄=其他可疑 / 橙=已自动校正。"
    r=5
    for i,h in enumerate(head):
        c=ws.cell(r,i+1,h); c.fill=HDR; c.font=Font(bold=True,color="FFFFFF")
    for row in summary:
        r+=1
        for i,v in enumerate(row):
            c=ws.cell(r,i+1,v)
            if i>=3 and v: c.fill=YEL
    r+=2; ws.cell(r,1,"问题明细").font=Font(bold=True,size=12)
    r+=1
    for i,h in enumerate(["舱/表","页码","位置","说明"]):
        c=ws.cell(r,i+1,h); c.fill=HDR; c.font=Font(bold=True,color="FFFFFF")
    if not issues: ws.cell(r+1,1,"未发现问题")
    for it in issues:
        r+=1
        for i,v in enumerate(it): ws.cell(r,i+1,v)
    for col,w in zip("ABCDEF",[30,12,26,60,12,12]): ws.column_dimensions[col].width=w
