"""Reference implementation (Python) of the extraction + validation logic.
The Kotlin core mirrors this file 1:1. Usable on desktop for text-layer PDFs."""
import re, statistics, collections

# ---------------- schemas ----------------
# (key, label, unit, decimals, group)
SOUNDING_COLS = (
    [("gauge","GAUGE","cm",0,"测深"),("ull","ULL","cm",0,"测深")]
    + [(f"tr{t}",f"tr={t}","m³",2,"纵倾下容积 Volume by trim (m)") for t in
       ["0","-0.5","-1","-1.5","-2","-2.5","-3","-3.5","-4","0.5","1"]]
    + [(h,h,"m³",2,"横倾容积 Heel volume") for h in ["HC3P","HC2P","HC1P","HC3S","HC2S","HC1S"]]
    + [("fill","FILL","%",1,"充满度"),
       ("lcg","L.C.G","m",2,"重心 CG"),("tcg","T.C.G","m",2,"重心 CG"),("vcg","V.C.G","m",2,"重心 CG"),
       ("imom","IMOM","m⁴",1,"自由液面惯性矩")]
)
HYDRO_COLS = [(k,k,u,d,"") for k,u,d in [
    ("T","m",3),("TK","m",3),("VOLM","m³",1),("DISP","t",1),("LCA","m",3),("CB","",4),("LCB","m",3),
    ("VCB","m",3),("KMT","m",3),("KML","m",3),("DISF","t",1),("LWL","m",2),("WLA","m²",1),
    ("AREA","m²",1),("TCP","t/cm",1),("MCT","tm/cm",1),("CW","",4),("CP","",4),("CM","",4)]]

NUM = r"-?\d+\.\d+"
def normalize(s):
    s = s.replace(",", ".").replace("—","-").replace("–","-").replace("−","-")
    tbl = str.maketrans({"O":"0","o":"0","Q":"0","D":"0","l":"1","I":"1","|":"1","i":"1","S":"5","s":"5","B":"8","Z":"2","z":"2"})
    out=[]
    for ch in s:
        out.append(ch.translate(tbl) if True else ch)
    s="".join(out)
    return re.sub(r"[^0-9.\-]", "", s)

def segment(rest, cols):
    """Split a de-spaced numeric string into len(cols) numbers using the fixed decimals per column."""
    vals=[]; pos=0
    for (_,_,_,d,_) in cols:
        m = re.match(r"-?\d+\.\d{%d}" % d if d>0 else r"-?\d+", rest[pos:])
        if not m: return None, pos
        vals.append(m.group(0)); pos += m.end()
    if pos != len(rest): return vals, -pos   # trailing garbage
    return vals, pos

def parse_row(line, cols, int_lead):
    """int_lead = number of leading integer columns separated by spaces (sounding: 2, hydro: 0)."""
    toks = line.split()
    if len(toks) < int_lead: return None
    lead = [normalize(t) for t in toks[:int_lead]]
    if any(not re.fullmatch(r"\d+", x) for x in lead): return None
    rest = normalize("".join(toks[int_lead:]))
    vals, pos = segment(rest, cols[int_lead:])
    if vals is None or pos < 0: 
        return ("bad", lead, rest)
    return ("ok", [float(x) for x in lead+vals])

def split_pages(txt): return txt.split("\f")

# ---------------- sounding ----------------
def parse_sounding(pages):
    comps=collections.OrderedDict(); issues=[]
    cur=None
    for pno,text in enumerate(pages,1):
        lines=text.split("\n")
        if not any("Volume in m3" in l for l in lines): continue
        name=None; meta={}
        for l in lines:
            m=re.match(r"\s*(\d+)\s+compart\w*\s*:\s*(.+?)\s*$", l, re.I)
            if m: meta["no"]=m.group(1); meta["name_hdr"]=m.group(2)
            m=re.match(r"\s*Compartment ident\s*:\s*(.+?)\s*$", l); 
            if m: meta["ident"]=m.group(1)
            m=re.match(r"\s*Contents\s*:\s*(.+?)\s*$", l)
            if m: meta["contents"]=m.group(1)
            m=re.match(r"\s*(.+?)\s*-\s*Volume in m3", l)
            if m: name=m.group(1).strip()
            if re.match(r"\s*Extreme points", l) or re.match(r"\s*Aft end", l) or re.match(r"\s*Fore end", l):
                meta.setdefault("extreme",[]).append(re.sub(r"^.*?(Extreme points of comp:|)\s*","",l).strip() if False else l.strip())
            if re.match(r"\s*(Sounding device|x =|y =|z =)", l): meta.setdefault("device",[]).append(l.strip())
        if "name_hdr" in meta:
            name = meta["name_hdr"] if not name else (name if name==meta["name_hdr"] else meta["name_hdr"])
            if name!=meta["name_hdr"]: pass
        if name is None:
            if cur is None: issues.append((pno,"-","未找到舱名,已跳过")); continue
            name=cur
        if "no" in meta or name not in comps:
            if name not in comps: comps[name]=dict(meta=meta, rows=[], pages=[])
            else: name=name+"#2"; comps[name]=dict(meta=meta, rows=[], pages=[])
        cur=name; c=comps[cur]; c["pages"].append(pno)
        for l in lines:
            if not re.match(r"^\s*\d+\s+\d+\s+-?\d", l): continue
            r=parse_row(l, SOUNDING_COLS, 2)
            if r is None: continue
            if r[0]=="bad": issues.append((pno,cur,f"行无法解析: {l.strip()[:60]}")); c["rows"].append((pno,None,l)); continue
            c["rows"].append((pno,r[1],l))
    return comps, issues


# ---------------- hydrostatics ----------------
def parse_hydro(pages):
    rows=[]; issues=[]; trim=None
    for pno,text in enumerate(pages,1):
        for l in text.split("\n"):
            m=re.search(r"Trim\s*=\s*(-?[\d.]+)", l)
            if m: trim=float(m.group(1)); continue
            if not re.match(r"^\s*\d+\.\d{3}\s", l): continue
            r=parse_row(l, HYDRO_COLS, 0)
            if r is None: continue
            if r[0]=="bad":
                issues.append((pno,"静水力",f"行无法解析: {l.strip()[:70]}")); rows.append((pno,trim,None,l)); continue
            rows.append((pno,trim,r[1],l))
    return rows, issues

# ---------------- validation ----------------
def flag(flags,r,c,why): flags.setdefault((r,c),[]).append(why)

def validate_sounding(rows):
    """rows: list of (page, values|None, raw). returns (fixed_values, flags, notes)"""
    vals=[list(r[1]) if r[1] else None for r in rows]
    flags={}; notes=[]
    good=[v for v in vals if v]
    if len(good)<3: return vals,flags,notes
    sums=collections.Counter(int(v[0]+v[1]) for v in good); const=sums.most_common(1)[0][0]
    diffs=[int(b[0]-a[0]) for a,b in zip(good,good[1:]) if b[0]>a[0]]
    step=collections.Counter(diffs).most_common(1)[0][0] if diffs else 5
    prev=None
    for i,v in enumerate(vals):
        if v is None: continue
        g,u=int(v[0]),int(v[1])
        if g+u!=const:
            exp_g = (prev+step) if prev is not None else None
            if exp_g is not None and g!=exp_g and u==const-exp_g:
                notes.append((rows[i][0],i,"GAUGE",f"{g}→{exp_g}(按ULL与序列校正)")); v[0]=float(exp_g); g=exp_g
            else:
                notes.append((rows[i][0],i,"ULL",f"{u}→{const-g}(按GAUGE+ULL恒等校正)")); v[1]=float(const-g)
        if prev is not None and v[0]-prev!=step:
            if v[0]-prev>step: flag(flags,i,0,f"测深间隔{int(v[0]-prev)}cm≠{step}cm,疑似漏行")
            else: flag(flags,i,0,"测深值非递增")
        prev=int(v[0])
    # fill vs tr0 volume
    gv=[v for v in vals if v]
    vmax=max(v[2] for v in gv) if gv else 0
    return vals,flags,notes,const,step

# ---------------- validation (final) ----------------
def validate_sounding(rows):
    vals=[list(r[1]) if r[1] else None for r in rows]
    flags={}; notes=[]
    good=[(i,v) for i,v in enumerate(vals) if v]
    if len(good)<3: return vals,flags,notes
    const=collections.Counter(int(v[0]+v[1]) for _,v in good).most_common(1)[0][0]
    diffs=[int(b[1][0]-a[1][0]) for a,b in zip(good,good[1:]) if b[1][0]>a[1][0]]
    step=collections.Counter(diffs).most_common(1)[0][0] if diffs else 5
    last_i=good[-1][0]; prev=None
    for i,v in good:
        g,u=int(v[0]),int(v[1])
        if abs(g+u-const)>1:                       # source rounding gives +-1, more means OCR error
            exp_g=(prev+step) if prev is not None else None
            if exp_g is not None and g!=exp_g and abs(u-(const-exp_g))<=1:
                notes.append((rows[i][0],i,"GAUGE",f"{g}→{exp_g}")); v[0]=float(exp_g); g=exp_g
            else:
                notes.append((rows[i][0],i,"ULL",f"{u}→{const-g}")); v[1]=float(const-g)
        if prev is not None and i!=last_i and int(v[0])-prev!=step:
            flag(flags,i,0,"测深间隔异常,疑似漏行/误识别" if v[0]-prev>step else "测深值未递增")
        prev=int(v[0])
    cap=max(v[2] for _,v in good)
    for i,v in good:
        if abs(100*v[2]/cap-v[19])>3: flag(flags,i,19,"FILL与容积不符")
    for (i,a),(j,b) in zip(good,good[1:]):
        if b[2]<a[2]-0.005: flag(flags,j,2,"容积回落")
        if b[19]<a[19]-0.05: flag(flags,j,19,"FILL回落")
    # per-column smoothness for volume / CG / imom columns
    for ci in list(range(2,13))+[20,21,22]:
        xs=[v[ci] for _,v in good]; idx=[i for i,_ in good]; dec=SOUNDING_COLS[ci][3]
        d2=[abs(xs[k-1]-2*xs[k]+xs[k+1]) for k in range(1,len(xs)-1)]
        for k in range(1,len(xs)-1):
            lo=max(0,k-1-12); hi=min(len(d2),k-1+12)
            sc=statistics.median(d2[lo:hi]) if hi>lo else 0
            res=abs(xs[k]-(xs[k-1]+xs[k+1])/2)
            big = max(25*sc, 40*10**-dec, 0.02*abs(xs[k]))
            if res>big and abs(xs[k]-xs[k-1])>big and abs(xs[k]-xs[k+1])>big:
                flag(flags,idx[k],ci,"数值与相邻行不连续")
    return vals,flags,notes

def validate_hydro(rows):
    vals=[list(r[2]) if r[2] else None for r in rows]; flags={}; notes=[]
    good=[(i,v) for i,v in enumerate(vals) if v]
    for i,v in good:
        if abs(v[1]-v[0]-0.017)>0.0015: flag(flags,i,1,"TK≠T+0.017")
        if v[2] and abs(v[3]/v[2]-1.025)>0.0035 and abs(v[3]/v[2]-1.0272)>0.0035: pass
    for ci in range(2,19):
        dec=HYDRO_COLS[ci][3]
        for k in range(1,len(good)-1):
            (i0,a),(i1,b),(i2,c)=good[k-1],good[k],good[k+1]
            if (c[0]-a[0])==0: continue
            w=(b[0]-a[0])/(c[0]-a[0]); pred=a[ci]+(c[ci]-a[ci])*w
            res=abs(b[ci]-pred)
            lo=max(1,k-10); hi=min(len(good)-1,k+10)
            sc=statistics.median(abs(good[m][1][ci]-(good[m-1][1][ci]+good[m+1][1][ci])/2) for m in range(lo,hi)) if hi>lo else 0
            if res>max(6*sc,4*10**-dec,0.0006*abs(b[ci])):
                flag(flags,i1,ci,"与相邻行不连续(源文件数据疑似异常或识别错误)")
    return vals,flags,notes
