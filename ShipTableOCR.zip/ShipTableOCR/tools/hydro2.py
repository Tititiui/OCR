import re, collections
HDEC={"T":3,"TK":3,"VOLM":1,"DISP":1,"LCA":3,"CB":4,"LCB":3,"VCB":3,"KMT":3,"KML":3,"DISF":1,"LWL":2,"WLA":1,"AREA":1,"WSA":1,"TCP":1,"MCT":1,"CW":4,"CP":4,"CM":4}
def parse_hydro_multi(pages):
    """Header-driven: every page carries its own header line; blocks with different headers are merged on T."""
    blocks=collections.OrderedDict()   # labels tuple -> {Tkey: (page, values)}
    order=[]; cols=None; issues=[]
    for pno,text in enumerate(pages,1):
        for l in text.split("\n"):
            tk=l.split()
            if len(tk)>=5 and tk[0]=="T" and all(re.fullmatch(r"[A-Z]+",x) for x in tk) and sum(x in HDEC for x in tk)>=4:
                cols=tuple(tk); blocks.setdefault(cols,collections.OrderedDict()); continue
            if cols is None or not re.match(r"^\s*\d+\.\d{3}\s",l): continue
            decs=[HDEC[c] for c in cols]
            rest="".join(tk); 
            vals=[];pos=0;ok=True
            for d in decs:
                m=re.match(r"-?\d+\.\d{%d}"%d,rest[pos:])
                if not m: ok=False;break
                vals.append(float(m.group(0)));pos+=m.end()
            if not ok or pos!=len(rest): issues.append((pno,"行无法解析",l.strip()[:60])); continue
            blocks[cols][round(vals[0],3)]=(pno,vals)
    labels=[]
    for cols in blocks:
        for c in cols:
            if c not in labels: labels.append(c)
    keys=list(next(iter(blocks.values())).keys()) if blocks else []
    for b in blocks.values():
        for k in b:
            if k not in keys: keys.append(k)
    keys.sort()
    rows=[]
    for k in keys:
        row=[None]*len(labels); pg=None
        for cols,b in blocks.items():
            if k in b:
                pg=b[k][0] if pg is None else pg
                for c,v in zip(cols,b[k][1]):
                    i=labels.index(c)
                    if row[i] is None: row[i]=v
        rows.append((pg,row))
    return labels,rows,issues,list(blocks.keys())
