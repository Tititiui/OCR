def trend_anomalies(xs, dec, max_short=3, min_side=5, max_gap=1):
    """Indices of a short run that reverses an established trend and then returns to it (spike / glitch).
    * moves within ~1 printed digit are 'flat': plateaus are normal and never flagged
    * flagged run: <= max_short steps; both neighbours run the opposite way, each >= min_side steps,
      and are adjacent to it (at most max_gap flat steps in between) -> tank-top jitter after a long plateau is ignored."""
    n=len(xs); eps=1.5*10**-dec
    runs=[]; flats=0   # run = [dir, first_idx, last_idx, steps, flats_before]
    for i in range(1,n):
        d=xs[i]-xs[i-1]
        s=1 if d>eps else -1 if d<-eps else 0
        if s==0: flats+=1; continue
        if runs and runs[-1][0]==s and flats<=max_gap: runs[-1][2]=i; runs[-1][3]+=1
        else: runs.append([s, runs[-1][2] if runs else i-1, i, 1, flats])
        flats=0
    bad=[]
    for k in range(1,len(runs)-1):
        r,a,b=runs[k],runs[k-1],runs[k+1]
        if r[3]<=max_short and a[0]==-r[0] and b[0]==-r[0] and a[3]>=min_side and b[3]>=min_side and r[4]<=max_gap and b[4]<=max_gap:
            bad.append((r[1],r[2],r[0]))
    return bad

def spikes(xs, dec, k=8.0, min_units=10, win=8):
    """Isolated single-point peaks/troughs far outside the local step size (e.g. 218.77, 78.10, 218.73)."""
    n=len(xs); u=10**-dec; out=[]
    for i in range(1,n-1):
        a=xs[i]-xs[i-1]; b=xs[i]-xs[i+1]
        if a*b<=0: continue
        exc=min(abs(a),abs(b))
        lo=max(1,i-win); hi=min(n-1,i+win)
        steps=sorted(abs(xs[j]-xs[j-1]) for j in range(lo,hi+1) if j not in (i,i+1))
        med=steps[len(steps)//2] if steps else 0
        if exc>=min_units*u and exc>=k*med: out.append(i)
    return out

def all_anomalies(xs, dec):
    """-> sorted set of indices to mark red (trend reversal runs + isolated spikes)."""
    s=set(spikes(xs,dec))
    for a,b,_ in trend_anomalies(xs,dec): s.update(range(a,b+1))
    return sorted(s)
