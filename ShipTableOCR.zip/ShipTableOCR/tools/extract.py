#!/usr/bin/env python3
"""Desktop reference of the app's logic for TEXT-LAYER PDFs (needs poppler's `pdftotext`, `openpyxl`).
   python extract.py sounding  in.pdf out.xlsx
   python extract.py hydro     in.pdf out.xlsx
The Kotlin `core` module implements the same rules (+ OCR / watermark removal for scans)."""
import subprocess, sys, statistics, collections
from openpyxl import Workbook
from openpyxl.styles import Font
import ship_tables as st, trend, hydro2, export_xlsx as ex

SKIP={'gauge','ull','HC3P','HC2P','HC1P','HC3S','HC2S','HC1S','imom'}
def pages_of(pdf):
    out=subprocess.run(['pdftotext','-layout',pdf,'-'],capture_output=True,text=True,errors='ignore').stdout
    return out.split('\f')

def check_sounding(rows):
    vals,flags,notes=st.validate_sounding(rows)[:3]
    flags={k:v for k,v in flags.items() if v[0] in ('测深间隔异常,疑似漏行/误识别','测深值未递增','FILL与容积不符')}
    good=[(i,v) for i,v in enumerate(vals) if v]; anoms={}
    for ci,col in enumerate(st.SOUNDING_COLS):
        if col[0] in SKIP: continue
        xs=[v[ci] for _,v in good]
        for k in trend.all_anomalies(xs,col[3]): anoms[(good[k][0],ci)]="趋势异常/孤立尖峰"
    return vals,flags,notes,anoms

def build_sounding(comps,path,source):
    wb=Workbook(); wb.remove(wb.active); used=set(); summary=[]; issues=[]; review=[]
    for name,c in comps.items():
        vals,flags,notes,anoms=check_sounding(c['rows'])
        fixed={(n[1],0 if n[2]=='GAUGE' else 1) for n in notes}
        ws=wb.create_sheet(ex.safe_sheet(name,used)); m=c['meta']
        meta=[f"Compartment ident: {m.get('ident','')}   |   {m.get('contents','')}","   ".join(m.get('extreme',[])),"   ".join(m.get('device',[])),
              f"来源页(PDF页码): {c['pages'][0]}–{c['pages'][-1]}   行数: {len(vals)}   (Volume in m³)"]
        ex.write_table(ws,name,meta,st.SOUNDING_COLS,vals,flags,fixed,anoms)
        for (r,cc),w in anoms.items():
            review.append((name,c['rows'][r][0],f"GAUGE={int(vals[r][0])}  列{st.SOUNDING_COLS[cc][1]}",vals[r][cc],w))
        for (r,cc),w in flags.items(): issues.append((name,c['rows'][r][0],f"行{r+1} 列{st.SOUNDING_COLS[cc][1]}",w[0]))
        for n in notes: issues.append((name,n[0],f"行{n[1]+1} {n[2]}",f"已自动校正 {n[3]}"))
        summary.append((name,f"{c['pages'][0]}–{c['pages'][-1]}",len(vals),0,len(notes),len(flags)+len(anoms)))
    finish(wb,path,source,'测深表 Sounding Table',summary,issues,review); return summary,review

def build_hydro(pages,path,source):
    labels,rows,iss,blocks=hydro2.parse_hydro_multi(pages)
    cols=[(l,l,{'T':'m','TK':'m','VOLM':'m³','DISP':'t','LCA':'m','CB':'','LCB':'m','VCB':'m','KMT':'m','KML':'m','DISF':'t','LWL':'m','WLA':'m²','AREA':'m²','WSA':'m²','TCP':'t/cm','MCT':'tm/cm'}.get(l,''),hydro2.HDEC[l],'') for l in labels]
    vals=[r for _,r in rows]; anoms={}; flags={}
    for ci,l in enumerate(labels):
        if l in ('T','TK'): continue
        for k in trend.all_anomalies([v[ci] for v in vals],hydro2.HDEC[l]): anoms[(k,ci)]="趋势异常/孤立尖峰"
    wb=Workbook(); ws=wb.active; ws.title='静水力参数'
    pg=[p for p,_ in rows]
    ex.write_table(ws,'静水力参数表 Hydrostatic Table',[f"列组: {len(blocks)} 组表头已按 T 合并   |   来源页(PDF页码): {min(pg)}–{max(pg)}   行数: {len(rows)}"],cols,vals,flags,set(),anoms)
    review=[('静水力',rows[r][0],f"T={vals[r][0]}  列{labels[cc]}",vals[r][cc],w) for (r,cc),w in sorted(anoms.items())]
    finish(wb,path,source,'静水力参数 Hydrostatics',[('静水力参数',f"{min(pg)}–{max(pg)}",len(rows),len(iss),0,len(anoms))],[('静水力',p,'行',m) for p,m,_ in iss],review)
    return len(rows),review

def finish(wb,path,source,kind,summary,issues,review):
    ws=wb.create_sheet('待校对清单'); ws['A1']='待校对清单(趋势异常,请对照原件手动校对)'; ws['A1'].font=Font(size=16,bold=True,color='1F3864')
    ws['A2']='规则:数据应单调上升/下降或先降后升/先升后降,不变属正常;连续趋势中突然反向数步又恢复、或孤立尖峰 → 标红。水箱满舱附近的小幅抖动可能是源表本身特性。'
    for i,h in enumerate(['舱 / 表','页码','位置','数值','原因']):
        c=ws.cell(4,i+1,h); c.fill=ex.HDR; c.font=Font(bold=True,color='FFFFFF')
    for r,row in enumerate(review,5):
        for i,v in enumerate(row):
            c=ws.cell(r,i+1,v)
            if i==3: c.fill=ex.RED
    for col,w in zip('ABCDE',[30,8,34,14,60]): ws.column_dimensions[col].width=w
    ex.write_report(wb,source,kind,["舱 / 表","来源页","行数","无法解析行","自动校正","可疑/异常单元格"],summary,issues)
    wb.save(path)

if __name__=='__main__':
    kind,pdf,out=sys.argv[1:4]; pg=pages_of(pdf)
    if kind=='sounding':
        comps,iss=st.parse_sounding(pg); s,r=build_sounding(comps,out,pdf); print(len(s),'compartments, red cells:',len(r))
    else:
        n,r=build_hydro(pg,out,pdf); print(n,'rows, red cells:',len(r))
