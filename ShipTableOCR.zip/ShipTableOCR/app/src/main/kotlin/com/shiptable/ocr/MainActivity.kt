package com.shiptable.ocr

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import ship.core.DocKind

class UiState(
    val kind: Int = 0, val removeWm: Boolean = true, val exportPdf: Boolean = false,
    val running: Boolean = false, val progress: Float = 0f, val status: String = "",
    val result: Result? = null, val error: String? = null
)

class MainVM(app: Application) : AndroidViewModel(app) {
    var ui by mutableStateOf(UiState())
        private set

    fun setKind(k: Int) { ui = copy(kind = k) }
    fun setWm(b: Boolean) { ui = copy(removeWm = b) }
    fun setPdf(b: Boolean) { ui = copy(exportPdf = b) }
    private fun copy(kind: Int = ui.kind, removeWm: Boolean = ui.removeWm, exportPdf: Boolean = ui.exportPdf, running: Boolean = ui.running,
                     progress: Float = ui.progress, status: String = ui.status, result: Result? = ui.result, error: String? = ui.error) =
        UiState(kind, removeWm, exportPdf, running, progress, status, result, error)

    fun start(uri: Uri) {
        val ctx = getApplication<Application>()
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "document.pdf"
        ui = copy(running = true, progress = 0f, status = "准备中…", result = null, error = null)
        val forced = when (ui.kind) { 1 -> DocKind.SOUNDING; 2 -> DocKind.HYDRO; else -> null }
        viewModelScope.launch {
            try {
                val r = Pipeline(ctx, forced, ui.removeWm, ui.exportPdf).run(uri, name) { p ->
                    ui = copy(progress = p.done.toFloat() / maxOf(1, p.total), status = p.msg)
                }
                ui = copy(running = false, result = r, status = "完成")
            } catch (e: Throwable) {
                ui = copy(running = false, error = e.message ?: e.toString())
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } } }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Screen(vm: MainVM = viewModel()) {
        val s = vm.ui
        val ctx = this
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.start(u) }
        val saveXlsx = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        ) { u ->
            val r = vm.ui.result
            if (u != null && r != null) { contentResolver.openOutputStream(u)!!.use { it.write(r.xlsx) }; Toast.makeText(ctx, "已保存 Excel", Toast.LENGTH_SHORT).show() }
        }
        val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { u ->
            val f = vm.ui.result?.cleanPdf
            if (u != null && f != null) { contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }; Toast.makeText(ctx, "已保存去水印PDF", Toast.LENGTH_SHORT).show() }
        }
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("船舶表格识别", style = MaterialTheme.typography.headlineSmall)
            Text("测深表 / 静水力参数 → Excel(完全离线)", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("自动识别", "测深表", "静水力").forEachIndexed { i, t -> FilterChip(selected = s.kind == i, onClick = { vm.setKind(i) }, label = { Text(t) }) }
            }
            Row { Text("去水印", Modifier.weight(1f)); Switch(s.removeWm, { vm.setWm(it) }) }
            if (s.removeWm) Row { Text("同时导出去水印PDF(仅图片页)", Modifier.weight(1f)); Switch(s.exportPdf, { vm.setPdf(it) }) }
            Button(onClick = { pick.launch(arrayOf("application/pdf")) }, enabled = !s.running, modifier = Modifier.fillMaxWidth()) { Text("选择 PDF 并开始识别") }
            if (s.running) { LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth()); Text(s.status) }
            s.error?.let { Text("失败:$it", color = Color(0xFFB00020)) }
            s.result?.let { r ->
                val sm = r.summary
                Card { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    sm.lines.forEach { Text(it) }
                    r.notes.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                } }
                if (sm.review.isNotEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE0E0))) { Column(Modifier.padding(12.dp)) {
                        Text("★ 需要手动校对(趋势异常:${sm.review.size} 处)", color = Color(0xFFB00020), style = MaterialTheme.typography.titleSmall)
                        sm.review.take(40).forEach { Text("${it.where} · 第${it.page}页 · ${it.pos}\n   ${it.msg}", style = MaterialTheme.typography.bodySmall) }
                        if (sm.review.size > 40) Text("…其余 ${sm.review.size - 40} 处见 Excel「待校对清单」")
                    } }
                } else Text("✓ 未发现趋势异常", color = Color(0xFF1B7F3B))
                val other = sm.issues.filter { it.msg.contains("无法") || it.msg.contains("未识别") || it.msg.contains("缺失") || it.msg.contains("校正") }
                if (other.isNotEmpty()) Card { Column(Modifier.padding(12.dp)) {
                    Text("识别问题 / 自动校正(${other.size})", style = MaterialTheme.typography.titleSmall)
                    other.take(15).forEach { Text("${it.where} · 第${it.page}页 · ${it.pos}: ${it.msg}", style = MaterialTheme.typography.bodySmall) }
                } }
                Button(onClick = { saveXlsx.launch(r.baseName + "_识别结果.xlsx") }, modifier = Modifier.fillMaxWidth()) { Text("保存 Excel") }
                if (r.cleanPdf != null) OutlinedButton(onClick = { savePdf.launch(r.baseName + "_去水印.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("保存去水印 PDF") }
            }
        }
    }
}
