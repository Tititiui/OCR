package com.shiptable.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ship.core.*
import java.io.File

class Progress(val done: Int, val total: Int, val msg: String)
class Result(val xlsx: ByteArray, val summary: Summary, val cleanPdf: File?, val notes: List<String>, val baseName: String)

/**
 * PDF → (text layer | watermark removal + OCR) → lines → parsers → validation → .xlsx
 * Everything is local; the app has no INTERNET permission.
 */
class Pipeline(
    private val ctx: Context,
    private val forced: DocKind?,
    private val removeWatermark: Boolean,
    private val exportCleanPdf: Boolean
) {
    suspend fun run(uri: Uri, displayName: String, onProgress: (Progress) -> Unit): Result = withContext(Dispatchers.Default) {
        PDFBoxResourceLoader.init(ctx)
        val src = File(ctx.cacheDir, "input.pdf")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> src.outputStream().use { o -> i.copyTo(o) } }
        val notes = ArrayList<String>()
        val issues = ArrayList<Issue>()
        val pages = ArrayList<PageContent>()
        val ocr = OcrEngine()
        val pdfOut = if (removeWatermark && exportCleanPdf) PdfDocument() else null
        var wmText = 0; var wmRaster = 0; var rasterPages = 0; var textPages = 0
        PDDocument.load(src).use { doc ->
            val pfd = ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY)
            PdfRenderer(pfd).use { renderer ->
                val n = renderer.pageCount
                for (i in 0 until n) {
                    onProgress(Progress(i, n, "第 ${i + 1}/$n 页"))
                    val tx = PdfText.extract(doc, i, removeWatermark)
                    if (tx.rotatedChars > 0) wmText++
                    if (PdfText.usable(tx)) {
                        textPages++
                        pages.add(PageContent(i + 1, tx.lines.map { TextLine.fromString(it) }, false))
                        continue
                    }
                    // image page (scan / photo): render → optional watermark removal → OCR
                    renderer.openPage(i).use { pg ->
                        val bmp = render(pg)
                        val px = IntArray(bmp.width * bmp.height)
                        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                        val rep = Watermark.detect(px, bmp.width, bmp.height)
                        if (rep.likely) wmRaster++
                        if (removeWatermark && rep.likely) {
                            Watermark.remove(px, bmp.width, bmp.height)
                            bmp.setPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                        }
                        if (pdfOut != null) {
                            val page = pdfOut.startPage(PdfDocument.PageInfo.Builder(pg.width, pg.height, i + 1).create())
                            page.canvas.drawBitmap(bmp, null, Rect(0, 0, pg.width, pg.height), Paint(Paint.FILTER_BITMAP_FLAG))
                            pdfOut.finishPage(page)
                        }
                        val words = ocr.words(bmp)
                        bmp.recycle()
                        rasterPages++
                        pages.add(PageContent(i + 1, LineBuilder.build(words), true))
                    }
                }
            }
        }
        ocr.close()
        var cleanFile: File? = null
        if (pdfOut != null && rasterPages > 0) {
            cleanFile = File(ctx.cacheDir, "cleaned.pdf")
            cleanFile.outputStream().use { pdfOut.writeTo(it) }
        }
        pdfOut?.close()

        notes.add("页面来源: 文字层 $textPages 页(数字无误差) / 图片OCR $rasterPages 页")
        if (wmText + wmRaster > 0) {
            notes.add(
                if (removeWatermark) "已检测并去除水印:文字层斜向文字 $wmText 页、图片水印 $wmRaster 页(原文件未被修改)"
                else "检测到水印(文字层 $wmText 页 / 图片 $wmRaster 页),但「去水印」未开启,识别可能受影响"
            )
        }
        if (wmText > 0 && removeWatermark) notes.add("文字层PDF的水印仅在识别时被忽略,不会改写原PDF;去水印后的PDF只对图片页生成。")

        val kind = forced ?: pages.mapNotNull { Parsers.classify(it.lines) }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        ?: throw IllegalStateException("无法判断是测深表还是静水力表,请在界面中手动选择类型")
        val tables = if (kind == DocKind.SOUNDING) Parsers.sounding(pages, issues) else listOf(Parsers.hydro(pages, issues))
        if (tables.isEmpty() || tables.all { it.rows.isEmpty() }) throw IllegalStateException("没有识别到任何表格数据行")
        onProgress(Progress(pages.size, pages.size, "生成 Excel…"))
        val (bytes, summary) = Export.build(kind, tables, displayName, issues, notes.joinToString("  |  "))
        Result(bytes, summary, cleanFile, notes, displayName.substringBeforeLast('.'))
    }

    private fun render(pg: PdfRenderer.Page): Bitmap {
        val scale = minOf(4.5f, 3800f / maxOf(pg.width, pg.height))
        val bmp = Bitmap.createBitmap((pg.width * scale).toInt(), (pg.height * scale).toInt(), Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return bmp
    }
}
