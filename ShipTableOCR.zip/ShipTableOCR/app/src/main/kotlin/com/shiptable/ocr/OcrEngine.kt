package com.shiptable.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import ship.core.OcrWord

/** On-device ML Kit OCR (bundled model → works offline from the first launch). Page is OCR'd in overlapping strips for dense tables. */
class OcrEngine {
    private val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun words(bmp: Bitmap): List<OcrWord> {
        val h = bmp.height
        val strip = 700; val ov = 80
        val out = ArrayList<OcrWord>()
        var y0 = 0
        while (y0 < h) {
            val y1 = minOf(h, y0 + strip + ov)
            val crop = Bitmap.createBitmap(bmp, 0, y0, bmp.width, y1 - y0)
            val t = rec.process(InputImage.fromBitmap(crop, 0)).await()
            val coreTop = if (y0 == 0) 0 else y0 + ov / 2
            val coreBot = if (y1 >= h) h else y0 + strip + ov / 2
            for (b in t.textBlocks) for (l in b.lines) for (e in l.elements) {
                val r = e.boundingBox ?: continue
                val cy = y0 + (r.top + r.bottom) / 2f
                if (cy < coreTop || cy >= coreBot) continue
                out.add(OcrWord(e.text, r.left.toFloat(), (y0 + r.top).toFloat(), r.right.toFloat(), (y0 + r.bottom).toFloat()))
            }
            crop.recycle()
            y0 += strip
        }
        return out
    }

    fun close() = rec.close()
}
